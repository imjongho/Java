package nagadaFront;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class BackgroundPanel extends JPanel {
    ImageIcon image;

    public BackgroundPanel(String imagePath) {
        image = new ImageIcon(imagePath);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), this);
    }
}

public class NagadaJDialog extends JDialog {
    public JButton okButton1;
    public JButton okButton2;

    public NagadaJDialog(String title, String imagePath, String buttonImagePath, String buttonImage2Path) {
        this(title, imagePath, buttonImagePath, buttonImage2Path, null, null);
    }

    public NagadaJDialog(String title, String imagePath, String buttonImagePath1, String buttonImage2Path1,
                         String buttonImagePath2, String buttonImage2Path2) {
        super((JFrame) null, title, true);

        BackgroundPanel backgroundPanel = new BackgroundPanel(imagePath);

        ImageIcon icon = new ImageIcon(imagePath);
        int width = icon.getIconWidth();
        int height = icon.getIconHeight();

        okButton1 = new JButton(new ImageIcon(buttonImagePath1));
        okButton1.setPressedIcon(new ImageIcon(buttonImage2Path1));
        okButton1.setRolloverIcon(new ImageIcon(buttonImage2Path1));
        okButton1.setBorderPainted(false);
        okButton1.setFocusPainted(false);
        okButton1.setContentAreaFilled(false);
        okButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        backgroundPanel.setLayout(null);
        backgroundPanel.setBounds(0, 0, width, height);
        okButton1.setBounds(130, 147, 141, 55);

        backgroundPanel.add(okButton1);

        if (buttonImagePath2 != null) {
            okButton2 = new JButton(new ImageIcon(buttonImagePath2));
            okButton2.setPressedIcon(new ImageIcon(buttonImage2Path2));
            okButton2.setRolloverIcon(new ImageIcon(buttonImage2Path2));
            okButton2.setBorderPainted(false);
            okButton2.setFocusPainted(false);
            okButton2.setContentAreaFilled(false);
            okButton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
            okButton2.setBounds(10, 100, 100, 50);
            okButton1.setBounds(120, 100, 100, 50);
            backgroundPanel.add(okButton2);
        }

        add(backgroundPanel);
        setResizable(false);
        pack();
        setSize(400, 240);
        setLocationRelativeTo(null);
    }
}