package nagadaClient;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.Timer;
import java.util.HashMap;


class MyinfoPanel extends BackgroundPanel {

    private BackgroundPanel backgroundPanel;
    private Client client;

    private JLabel textID;
    private JPasswordField textPW;
    private JTextField textName;
    private JTextField textGender;
    private JTextField textAge;
    private JTextField textPhone;
    private JTextField textAcc;
    private JTextField textBank;
    private JButton ModiyCheck;

    private boolean isEditMode = false;
    private Timer updateTimer;    // 타이머 객체 생성

    public MyinfoPanel(Client client) {
        super("src/nagadaImg/Myinfo.png");
        setLayout(null); // No layout manager (null layout)
        // Components
        this.client = client;

        setLayout(null); // No layout manager (null layout)

        ImageIcon ModiyButton1 = new ImageIcon("src/nagadaImg/ModiyButton1.png");
        ImageIcon ModiyButton2 = new ImageIcon("src/nagadaImg/ModiyButton2.png");

        Image Modiyimg = ModiyButton2.getImage();
        Image changeModiy = Modiyimg.getScaledInstance(200, 73, Image.SCALE_SMOOTH);
        ImageIcon ModiyIcon = new ImageIcon(changeModiy);
        
        ModiyCheck = new JButton(ModiyButton1);
        ModiyCheck.setPressedIcon(ModiyIcon); // 눌렀을 때의 이미지
        ModiyCheck.setRolloverIcon(ModiyIcon); // 버튼에 마우스가 올라갈떄 이미지 변환
        ModiyCheck.setBorderPainted(false); // 버튼 테두리 설정해제
        ModiyCheck.setFocusPainted(false); // 누르면 생기는 테두리 해제
        ModiyCheck.setContentAreaFilled(false);
        ModiyCheck.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경

        // Components
        JLabel labelSignup = new JLabel(" ", SwingConstants.CENTER); // Set text alignment to center
        JLabel labelID = new JLabel(" ");
        JLabel labelPW = new JLabel(" ");
        JLabel labelName = new JLabel(" ");
        JLabel labelGender = new JLabel(" ");
        JLabel labelAge = new JLabel(" ");
        JLabel labelPhone = new JLabel(" ");
        JLabel labelAcc = new JLabel(" ");
        Font font = new Font("맑은 고딕", 1, 25);
        textID = new JLabel();	// 이것만 바뀌면 안됨 
        textID.setFont(font);
        textID.setBorder(null);
        textID.setOpaque(false);
        textPW = new JPasswordField();
        textPW.setFont(font);
        textPW.setBorder(null);
        textPW.setOpaque(false);
        textName = new JTextField();
        textName.setFont(font);
        textName.setBorder(null);
        textName.setOpaque(false);
        textGender = new JTextField();
        textGender.setFont(font);
        textGender.setOpaque(false);
        textGender.setBorder(null);
        textAge = new JTextField();
        textAge.setFont(font);
        textAge.setOpaque(false);
        textAge.setBorder(null);
        textPhone = new JTextField();
        textPhone.setFont(font);
        textPhone.setOpaque(false);
        textPhone.setBorder(null);
        textAcc = new JTextField();
        textAcc.setFont(font);
        textAcc.setOpaque(false);
        textAcc.setBorder(null);
        textBank = new JTextField();
        textBank.setFont(font);
        textBank.setOpaque(false);
        textBank.setBorder(null);

        int centerX = 250;
        labelSignup.setBounds(centerX + 10, 40, 200, 60);
        labelID.setBounds(centerX - 140, 131, 80, 40);
        textID.setBounds(centerX - 38, 131, 250, 40);
        labelPW.setBounds(centerX - 140, 202, 80, 40);
        textPW.setBounds(centerX - 38, 202, 250, 40);
        labelName.setBounds(centerX - 140, 278, 80, 40);
        textName.setBounds(centerX - 38, 278, 250, 40);
        labelGender.setBounds(centerX - 165, 363, 60, 40);
        textGender.setBounds(centerX - 78, 363, 60, 40);
        labelAge.setBounds(centerX + 55, 363, 60, 40);
        textAge.setBounds(centerX + 137, 363, 60, 40);
        labelPhone.setBounds(centerX - 160, 440, 80, 40);
        textPhone.setBounds(centerX - 38, 440, 250, 40);
        labelAcc.setBounds(centerX - 160, 520, 80, 40);
        textAcc.setBounds(centerX - 38, 520, 250, 40);
        textBank.setBounds(centerX + 286, 521, 89, 40);
        ModiyCheck.setBounds(centerX + 10, 588, 200, 73);


        add(labelSignup);
        add(labelID);
        add(labelPW);
        add(labelName);
        add(labelGender);
        add(labelAge);
        add(labelPhone);
        add(labelAcc);
        add(labelSignup);
        add(textID);
        add(textPW);
        add(textName);
        add(textGender);
        add(textAge);
        add(textPhone);
        add(textAcc);
        add(textBank);
        add(ModiyCheck);

        // Set the size of the JFrame and make it visible
        setSize(750, 750);
        setVisible(true);

        updateTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String receivedMessage = client.getReceivedMessage();
            	if (receivedMessage.startsWith("USER_INFO")) {
            	    updateUserInfoDisplay(receivedMessage);
            	}
            }
        });
        updateTimer.start(); // 타이머 시작
        
        
        ModiyCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isEditMode) {
                    // 사용자에게 수정 모드 진입을 확인
                    int confirm = JOptionPane.showConfirmDialog(null, "정보를 수정하시겠습니까?", "정보 수정", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        setEditMode(true);
                    }
                } else {
                    // 사용자 정보를 서버로 전송
                    updateUserInfo();
                }
            }
        });
    }

    public void updateUserInfoDisplay(String userInfoMessage) {
        // Split the message to extract user details
        String[] userDetails = userInfoMessage.split("\\|");
        if (userDetails.length < 9) {
            // Handle error - invalid message format
            System.err.println("Invalid USER_INFO message format.");
            return;
        }

        // Update UI components with user details
        textID.setText(userDetails[1]); // ID
        textPW.setText(userDetails[2]); // Password
        textName.setText(userDetails[3]); // Name
        textGender.setText(userDetails[4]); // Gender
        textAge.setText(userDetails[5]); // Age
        textPhone.setText(userDetails[6]); // Phone
        textAcc.setText(userDetails[7]); // Account
        textBank.setText(userDetails[8]); // Bank

        // Disable edit mode initially
        setEditMode(false);
    }
    
    private void setEditMode(boolean enabled) {
        // 텍스트 필드의 편집 가능 상태 설정
        textPW.setEditable(enabled);
        textName.setEditable(enabled);
        textGender.setEditable(enabled);
        textAge.setEditable(enabled);
        textPhone.setEditable(enabled);
        textAcc.setEditable(enabled);
        textBank.setEditable(enabled);
        isEditMode = enabled;
    }

    private void updateUserInfo() {
        // 사용자 정보를 텍스트 필드에서 가져옵니다.
        String id = textID.getText();
        String pw = new String(textPW.getPassword());
        String name = textName.getText();
        String gender = textGender.getText();
        String age = textAge.getText();
        String phone = textPhone.getText();
        String acc = textAcc.getText();
        String bank = textBank.getText();

        // 사용자 정보를 서버로 전송하기 위한 메시지를 구성합니다.
        String userInfoMessage = "UPDATE_USER_INFO|" + id + "|" + pw + "|" + name + "|" + gender + "|" + age + "|" + phone + "|" + acc + "|" + bank;
        client.sendMessage(userInfoMessage);

        Timer responseTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                String response = client.getReceivedMessage();
                if (response != null && response.equals("UPDATE_USER_INFO_SUCCESS")) {
                    JOptionPane.showMessageDialog(null, "정보가 성공적으로 업데이트되었습니다.");
                    setEditMode(false);
                    ((Timer) evt.getSource()).stop();
                }
            }
        });
        responseTimer.setRepeats(true);
        responseTimer.start();
    }
}






class MySchedulePanel extends JPanel {
    private Client client;
    private JPanel calendarPanel;
    private JComboBox<Integer> yearComboBox;
    private JComboBox<String> monthComboBox;
    private final int daysInWeek = 7;
    private final int maxWeeksInMonth = 6;
    
    private HashMap<String, String> dateStatusMap = new HashMap<>(); // 추가된 부분
    private Timer updateTimer;    // 타이머 객체 생성
    
    public MySchedulePanel(Client client) {
        this.client = client;
        setLayout(new BorderLayout());

        add(createControlPanel(), BorderLayout.NORTH);
        calendarPanel = createCalendarPanel(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH));
        calendarPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
        add(calendarPanel, BorderLayout.CENTER);

        updateTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String messages = client.getReceivedMessage();
                String[] parts = messages.split("\\|");
            	if(parts[0].equals("APPLICATION_DATES")) {
            		processApplicationDates(messages);
            	}
                
            }
        });
        updateTimer.start(); // 타이머 시작
        
    }

    private JPanel createControlPanel() {
        JPanel controlPanel = new JPanel();

        // 년도 선택 ComboBox
        yearComboBox = new JComboBox<>();
        for (int i = 1900; i <= 2100; i++) {
            yearComboBox.addItem(i);
        }
        yearComboBox.setSelectedItem(Calendar.getInstance().get(Calendar.YEAR));
        controlPanel.add(yearComboBox);

        // 월 선택 ComboBox
        monthComboBox = new JComboBox<>(new String[]{"1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"});
        monthComboBox.setSelectedIndex(Calendar.getInstance().get(Calendar.MONTH));
        controlPanel.add(monthComboBox);

        // 날짜 선택에 대한 이벤트 리스너
        ActionListener dateSelectionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateCalendar();
            }
        };

        yearComboBox.addActionListener(dateSelectionListener);
        monthComboBox.addActionListener(dateSelectionListener);

        return controlPanel;
    }

    private void updateCalendar() {
        int year = (int) yearComboBox.getSelectedItem();
        int month = monthComboBox.getSelectedIndex();

        remove(calendarPanel);
        calendarPanel = createCalendarPanel(year, month);
        add(calendarPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel createCalendarPanel(int year, int month) {
        JPanel calendarPanel = new JPanel(new BorderLayout());
        calendarPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        calendarPanel.setBackground(Color.WHITE);

        // Header panel with day names
        JPanel headerPanel = new JPanel(new GridLayout(1, daysInWeek));
        headerPanel.setBackground(Color.WHITE);
        String[] dayNames = {"일", "월", "화", "수", "목", "금", "토"};
        for (String dayName : dayNames) {
            JLabel dayLabel = new JLabel(dayName, SwingConstants.CENTER);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.black, 1));
            dayLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
            headerPanel.add(dayLabel);
        }
        calendarPanel.add(headerPanel, BorderLayout.NORTH);

        // Days panel with day numbers
        JPanel daysPanel = new JPanel(new GridLayout(maxWeeksInMonth, daysInWeek));

        daysPanel.setBackground(Color.WHITE);
        Calendar calendar = new GregorianCalendar(year, month, 1);
        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Calculate the previous month's days to display
        Calendar prevMonthCalendar = (Calendar) calendar.clone();
        prevMonthCalendar.add(Calendar.MONTH, -1);
        int prevMonthDays = prevMonthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        int prevMonthStart = prevMonthDays - firstDayOfWeek + 2;

        // Previous month days (faded)
        for (int i = 1; i < firstDayOfWeek; i++) {
            int day = prevMonthStart + i - 1;
            // Assuming previous month is month-1. Adjust if this logic is not correct.
            String prevMonthDateStr = String.format("%04d/%02d/%02d", year, month, day); 
            JLabel dayLabel = createDayLabel(Integer.toString(day), true, i % daysInWeek, prevMonthDateStr);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.black, 1)); // Border added
            daysPanel.add(dayLabel);
        }

        // Current month days
        for (int i = 1; i <= daysInMonth; i++) {
            // 날짜 문자열 생성
            String dateStr = String.format("%04d/%02d/%02d", year, month + 1, i);
            JLabel dayLabel = createDayLabel(Integer.toString(i), false, (i + firstDayOfWeek - 1) % daysInWeek, dateStr);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.black, 1));
            daysPanel.add(dayLabel);
        }

        // Next month days (faded)
        int nextMonthDay = 1;
        for (int i = daysPanel.getComponentCount(); i < daysInWeek * maxWeeksInMonth; i++) {
            // nextMonthDay에 대한 날짜 문자열 생성
            String nextMonthDateStr = String.format("%04d/%02d/%02d", year, month + 2, nextMonthDay++);
            JLabel dayLabel = createDayLabel(Integer.toString(nextMonthDay), true, i % daysInWeek, nextMonthDateStr);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.black, 1)); // 테두리 추가
            daysPanel.add(dayLabel);
        }

        calendarPanel.add(daysPanel, BorderLayout.CENTER);
        return calendarPanel;
    }

    
    // 새로 추가된 메서드
    public void processApplicationDates(String message) {
        String[] parts = message.split("\\|");
        for (int i = 1; i < parts.length; i += 3) {
            String date = parts[i];
            String period = parts[i + 1];
            String status = parts[i + 2];
            if(status.equals("출근O")) {	// 출근만 상태 표시
            	dateStatusMap.put(date, status + "(" + period + ")");
            }
        }
        updateCalendar();
    }
    
    
    private JLabel createDayLabel(String dayText, boolean isFaded, int dayOfWeek, String date) {
        JLabel dayLabel = new JLabel(dayText, SwingConstants.CENTER);
        if (isFaded) {
            dayLabel.setForeground(Color.LIGHT_GRAY);
        } else {
            dayLabel.setForeground(Color.BLACK);
            if (dayOfWeek == 1) { // Sunday
                Color qwer = Color.getHSBColor((float) 1, (float) 20.2, (float) 93.3);
                dayLabel.setBackground(qwer);
                dayLabel.setOpaque(true);
            } else if (dayOfWeek == 0) { // Saturday
                dayLabel.setBackground(Color.CYAN);
                dayLabel.setOpaque(true);
            } else {
                dayLabel.setBackground(Color.lightGray);
                dayLabel.setOpaque(true);
            }
        }
        
        if (dateStatusMap.containsKey(date)) {
            String additionalInfo = dateStatusMap.get(date);
            String formattedDate = String.format("<html><div style='text-align: center;'>%s<br/>%s</div></html>", dayLabel.getText(), additionalInfo);
            dayLabel.setText(formattedDate);
        }

        return dayLabel;
    }
}





class ApplyPanel extends JPanel {	// 패널 업데이트 될때 신청 버튼이 초기화되서 다시 눌린다 해결해야함
    
    private String[] dateLabels = new String[7];
    private String[] simpleDateLabels = new String[7]; // 서버에 보낼 간단한 날짜 형식
    private String[] statusLabelsDay = new String[7]; // 주간 상태 배열
    private String[] statusLabelsNight = new String[7]; // 야간 상태 배열
    private boolean[] hasAppliedDay = new boolean[7];  // 주간 신청 여부
    private boolean[] hasAppliedNight = new boolean[7]; // 야간 신청 여부
    private boolean[] hasConfirmedDay = new boolean[7];  // 주간 출근 여부
    private boolean[] hasConfirmedNight = new boolean[7]; // 야간 출근 여부
    
    
    private JPanel dayTimePanel;
    private JPanel nightTimePanel;
    
    private final int spacing = 10; // 모든 요소들 사이의 간격
    private Client client;
    private Calendar calendar = Calendar.getInstance();;
    private Calendar lastUpdated = Calendar.getInstance();
    private Timer updateTimer;    // 타이머 객체 생성

    private CancelPanel cancelPanel; // ApplyPanel의 참조를 저장
    
    public ApplyPanel(Client client) {
        this.client = client;
        setLayout(null);

        updateDateLabels(); // 초기에 날짜 레이블 업데이트
    	for(int i = 0; i < 7; i++) {
    		statusLabelsDay[i] = " ";
        	statusLabelsNight[i] = " ";
        	hasAppliedDay[i] = false;
        	hasAppliedNight[i] = false;
        	hasConfirmedDay[i] = false;
        	hasConfirmedNight[i] = false;
    	}
        
        // 날짜 라벨 위치 계산
        int dateLabelY = spacing;
        JLabel yearLabel = createLabel(calendar.get(Calendar.YEAR) + "년", 30, (750 - 350) / 2, dateLabelY, 320, 60, false, -1, "");
        add(yearLabel);

        // 주간 패널 위치 계산
        int dayTimePanelY = dateLabelY + 70 + spacing;
        dayTimePanel = createPanel(10, dayTimePanelY, 710, 270);
        setupDayOrNightPanel(dayTimePanel, "주간");
        add(dayTimePanel);

        // 야간 패널 위치 계산
        int nightTimePanelY = dayTimePanelY + 300 + spacing;
        nightTimePanel = createPanel(10, nightTimePanelY, 710, 270);
        setupDayOrNightPanel(nightTimePanel, "야간");
        add(nightTimePanel);
        
        // 위에는 GUI 생성할 때, 한번만 호출되기 때문에 이 부분에서 계속 반복적으로 작업하며 업데이트 진행 
        // 타이머 설정: 0.5초마다 체크
        updateTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 새로운 날이 시작되면 날짜 라벨 업데이트
                Calendar now = Calendar.getInstance();
                // 마지막 업데이트 날짜와 현재 날짜가 다른지 확인
                if (!isSameDay(lastUpdated, now)) {
                    updateDateLabels();
                    updatePanels();
                    lastUpdated = now; // 마지막 업데이트 날짜 갱신
                }
                
                // 여기에서 서버로부터 메시지를 확인하고 업데이트할 수 있도록 구현
                String messages = client.getReceivedMessage();
                String[] parts = messages.split("\\|");
            	if(parts[0].equals("BROADCAST") || parts[0].equals("APPLICATION_DATES") || parts[0].equals("CONFIRM")) {
            		processServerMessage(messages); // 받은 메시지 처리
            	}
                
            }
        });
        updateTimer.start(); // 타이머 시작
        
    }
    
    public void setCancelPanel(CancelPanel cancelPanel) {
        this.cancelPanel = cancelPanel;
    }
    
    
    // 두 Calendar 인스턴스가 같은 날짜인지 확인하는 메소드
    private boolean isSameDay(Calendar cal1, Calendar cal2) {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }
    
    private void setupDayOrNightPanel(JPanel panel, String dayOrNightLabel) {
        // 주간/야간 라벨 위치 계산
        int labelDayYPosition = spacing;
        JLabel labelDay = createLabel(dayOrNightLabel, 30, 10, labelDayYPosition, 100, 40, false, -1, "");
        panel.add(labelDay);

        int labelWidth = 90;
        int buttonWidth = 90;
        int startOffset = 10;

        int labelYPosition = labelDayYPosition + 40 + spacing;
        int elementHeight = 30;
        int dateLabelHeight = 270 - labelYPosition - (spacing * 3) - (elementHeight * 2);

        for (int i = 0; i < 7; i++) {
            int xPosition = startOffset + i * (labelWidth + spacing);

            JLabel dateLabel = createLabel(dateLabels[i], 14, xPosition, labelYPosition, labelWidth, dateLabelHeight, true, i, dayOrNightLabel);
            panel.add(dateLabel);

            int statusLabelY = labelYPosition + dateLabelHeight + spacing;
            String status = (dayOrNightLabel.equals("주간")) ? statusLabelsDay[i] : statusLabelsNight[i];
            JLabel statusLabel = createLabel(status, 14, xPosition, statusLabelY, labelWidth, elementHeight, false, -1, ""); // -1 and "" because they are not used here
            panel.add(statusLabel);

            int buttonY = statusLabelY + elementHeight + spacing;
            JButton button = createButton("신청", xPosition, buttonY, buttonWidth, elementHeight, i, dayOrNightLabel);
            panel.add(button);

        }
    }

    private void updatePanels() {
        remove(dayTimePanel);
        remove(nightTimePanel);
        
        int dayTimePanelY = 90; // 예시 Y 좌표
        dayTimePanel = createPanel(10, dayTimePanelY, 710, 270);
        setupDayOrNightPanel(dayTimePanel, "주간");
        add(dayTimePanel);

        int nightTimePanelY = 400; // 예시 Y 좌표
        nightTimePanel = createPanel(10, nightTimePanelY, 710, 270);
        setupDayOrNightPanel(nightTimePanel, "야간");
        add(nightTimePanel);
        
        revalidate();
        repaint();
    }
    
    
    // 브로드캐스트로 온 메시지로 인원이 얼마나 차 있는지 확인하는 상태 라벨 업데이트
    public void processServerMessage(String messages) {
        String[] parts = messages.split("\\|");
        if (parts.length >= 16 && parts[0].equals("BROADCAST")) {
        	String todayDate = parts[1]; // 오늘 날짜
        	if(todayDate.equals(simpleDateLabels[0])) {
                for (int i = 2; i < 9; i++) {	// 일주일 주간상태에 저장
                    if (!statusLabelsDay[i-2].equals("출근O") && !statusLabelsDay[i-2].equals("출근X")) {
                        statusLabelsDay[i-2] = parts[i];
                    }
                }
                
                for (int i = 9; i < 16; i++) {	// 일주일 야간상태에 저장                 
                    if (!statusLabelsNight[i-9].equals("출근O") && !statusLabelsNight[i-9].equals("출근X")) {
                        statusLabelsNight[i-9] = parts[i];
                    }
                }
        	}
        }
        
        
        if (parts.length > 0 && parts[0].equals("APPLICATION_DATES")) {
            // 기존 신청 및 출근 상태 초기화
            Arrays.fill(hasAppliedDay, false);
            Arrays.fill(hasAppliedNight, false);
            Arrays.fill(hasConfirmedDay, false);
            Arrays.fill(hasConfirmedNight, false);

            for (int i = 1; i < parts.length; i += 3) {
                String date = parts[i];
                String period = parts[i + 1];
                String status = parts[i + 2];
                int dateIndex = Arrays.asList(simpleDateLabels).indexOf(date);
                
                if (dateIndex != -1) {
                    if (period.equals("주간")) {
                        if (status.equals("신청")) {
                            hasAppliedDay[dateIndex] = true;
                        } else if (status.equals("출근O")) {
                            hasConfirmedDay[dateIndex] = true;
                            statusLabelsDay[dateIndex] = "출근O"; // 출근 상태 저장
                        } else if(status.equals("출근X")) {
                        	hasConfirmedDay[dateIndex] = true;
                        	statusLabelsDay[dateIndex] = "출근X";
                        }
                    } else if (period.equals("야간")) {
                        if (status.equals("신청")) {
                            hasAppliedNight[dateIndex] = true;
                        } else if (status.equals("출근O")) {
                            hasConfirmedNight[dateIndex] = true;
                            statusLabelsNight[dateIndex] = "출근O"; // 출근 상태 저장
                        }  else if(status.equals("출근X")) {
                        	hasConfirmedNight[dateIndex] = true;
                        	statusLabelsNight[dateIndex] = "출근X";
                        }
                    }
                }
            }
        }
        
        
        if (parts[0].equals("CONFIRM")) {
            for (int i = 1; i < parts.length; i += 3) {
                String date = parts[i];
                String period = parts[i + 1];
                boolean confirmed = Boolean.parseBoolean(parts[i + 2]);
                int dateIndex = Arrays.asList(simpleDateLabels).indexOf(date);

                if ((dateIndex != -1) && (confirmed == true)) {
                    if (period.equals("주간")) {
                        hasConfirmedDay[dateIndex] = true;
                        if(!statusLabelsDay[dateIndex].equals("출근O")) {
                        	statusLabelsDay[dateIndex] = "출근X";
                        }
                    } else {
                        hasConfirmedNight[dateIndex] = true;
                        if(!statusLabelsNight[dateIndex].equals("출근O")) {
                        	statusLabelsNight[dateIndex] = "출근X";
                        }
                    }
                }
            }
        }
        
          
        updatePanels();
    }
    
    

    
    // 날짜 라벨 업데이트
    private void updateDateLabels() {
        calendar = Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
        	int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1;
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            String dayOfWeek = new SimpleDateFormat("E").format(calendar.getTime());

            // UI에 표시될 날짜와 요일 (HTML 형식)
            String formattedDate = String.format("<html><div style='text-align: center;'>%02d/%02d<br/><br/>%s</div></html>", month, day, dayOfWeek);
            dateLabels[i] = formattedDate;

            // 서버에 보낼 간단한 날짜 형식
            simpleDateLabels[i] = String.format("%04d/%02d/%02d", year, month, day);

            calendar.add(Calendar.DATE, 1);
        }
    }

    private JLabel createLabel(String text, int fontSize, int x, int y, int width, int height, boolean isDateLabel, int index, String dayOrNight) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font(label.getFont().getName(), Font.PLAIN, fontSize));
        label.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // 경계선 색 변경
        label.setBackground(Color.WHITE); // 배경색 변경
        label.setOpaque(true); // JLabel 배경색 표시
        label.setForeground(Color.DARK_GRAY); // 글자색 변경
        label.setBounds(x, y, width, height);
        
        if (isDateLabel && index >= 0 && index < 7) {
            // Check the status corresponding to this date label
            String status = dayOrNight.equals("주간") ? statusLabelsDay[index] : statusLabelsNight[index];

            switch (status) {
                case "미만":
                    label.setBackground(Color.GREEN);
                    break;
                case "충족":
                    label.setBackground(Color.YELLOW);
                    break;
                case "초과":
                    label.setBackground(Color.RED);
                    break;
                case "준비중":
                    label.setBackground(Color.WHITE);
                    break;
                default:
                    label.setBackground(Color.WHITE); // Default background
                    break;
            }
        } else {
            // For non-date labels
            label.setBackground(Color.WHITE); // Default background
        }

        
        switch (text) {
        case "미만":
            label.setForeground(new Color(0, 128, 0)); // Dark green
            break;
        case "충족":
            label.setForeground(new Color(204, 204, 0)); // Dark yellow
            break;
        case "초과":
            label.setForeground(new Color(139, 0, 0)); // Dark red
            break;
        case "준비중":
            label.setForeground(Color.LIGHT_GRAY);
            break;
        default:
            label.setForeground(Color.BLACK);
            break;
        }
        
        return label;
    }

    private JButton createButton(String text, int x, int y, int width, int height, int index, String dayOrNight) {
        boolean hasApplied = (dayOrNight.equals("주간")) ? hasAppliedDay[index] : hasAppliedNight[index];
        boolean hasConfirmed = (dayOrNight.equals("주간")) ? hasConfirmedDay[index] : hasConfirmedNight[index];
        JButton button = new JButton(text);
        
        button.setBounds(x, y, width, height);
        button.setOpaque(true);
        button.setBackground(new Color(225, 225, 225)); // 버튼 배경색 변경
        button.setForeground(Color.DARK_GRAY); // 버튼 글자색 변경
        button.setFocusPainted(false); // 버튼 포커스 테두리 제거
        button.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        button.setActionCommand(dayOrNight + "|" + index); // 주간/야간과 인덱스 정보를 함께 저장
        
        if (hasConfirmed) {
            // 출근이 확정된 경우
            button.setText("마감");
            button.setEnabled(false);
        } else {
            // 출근이 확정되지 않은 경우
            String buttonText = hasApplied ? "신청완료" : "신청";
            button.setText(buttonText);
            button.setEnabled(!hasApplied);
            
            // 버튼 액션 리스너 설정
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (!hasApplied) {
                        // 버튼의 ActionCommand에서 날짜 정보와 주간/야간 정보를 가져옴
                        String[] commandParts = e.getActionCommand().split("\\|");
                        String period = commandParts[0];
                        int dateIndex = Integer.parseInt(commandParts[1]);
                        String date = simpleDateLabels[dateIndex]; // 실제 날짜 정보

                        // 확인 다이얼로그 메시지 생성
                        String confirmMessage = date + " (" + period + ") 신청하기";
                        
                        // 옵션 다이얼로그를 사용하여 사용자에게 확인 요청
                        int choice = JOptionPane.showOptionDialog(
                            null, // 부모 컴포넌트
                            confirmMessage, // 메시지
                            "신청확인", // 타이틀
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new String[]{"예", "아니오"}, // 버튼 텍스트
                            "예" // 기본 옵션
                        );

                        // 사용자가 "예"를 선택한 경우
                        if (choice == JOptionPane.YES_OPTION) {
                        	
                        	// 신청 완료 메시지를 다이얼로그로 표시
                            JOptionPane.showMessageDialog(null, "신청 완료!", "확인", JOptionPane.INFORMATION_MESSAGE);
                   
                            String applyMessage = "APPLY|" + period + "|" + date;
                            client.sendMessage(applyMessage);

                            Timer responseTimer = new Timer(100, new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent evt) {
                                    button.setText("신청완료");
                                    button.setEnabled(false);
                                    String response = client.getReceivedMessage();
                                    if (response != null && response.equals("APPLY_SUCCESS")) {
                                        cancelPanel.activateCancelButton(response, dateIndex, period);

                                        // 상태 배열을 업데이트
                                        if(period.equals("주간")) {
                                            hasAppliedDay[dateIndex] = true;
                                        } else {
                                            hasAppliedNight[dateIndex] = true;
                                        }
                                        
                                        updatePanels();
                                        ((Timer) evt.getSource()).stop();
                                    }
                                }
                            });
                            responseTimer.setRepeats(true);
                            responseTimer.start();
                        }
                    }
                }
            });
        }
   
        return button;
    }

    
    private JPanel createPanel(int x, int y, int width, int height) {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setOpaque(true);
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // 패널 경계선 색 변경
        panel.setBackground(Color.WHITE); // 패널 배경색 변경
        panel.setBounds(x, y, width, height);
        return panel;
    }
    
    
    public void activateApplyButton(String response, int index, String dayOrNight) {
        if (response.equals("CANCEL_SUCCESS")) {
            if (dayOrNight.equals("주간")) {
                hasAppliedDay[index] = false;
            } else {
                hasAppliedNight[index] = false;
            }
            updatePanels(); // 업데이트된 상태로 패널을 다시 그립니다.
        }
    }
    

}





class CancelPanel extends JPanel {
	
    private String[] dateLabels = new String[7];
    private String[] simpleDateLabels = new String[7]; // 서버에 보낼 간단한 날짜 형식
    private String[] myStatusLabelsDay = new String[7]; // 주간 상태 배열
    private String[] myStatusLabelsNight = new String[7]; // 야간 상태 배열
    private boolean[] hasAppliedDay = new boolean[7];  // 주간 취소 여부
    private boolean[] hasAppliedNight = new boolean[7]; // 야간 취소 여부
    private boolean[] hasConfirmedDay = new boolean[7];  // 주간 출근 여부
    private boolean[] hasConfirmedNight = new boolean[7]; // 야간 출근 여부
    
    private final int spacing = 10; // 모든 요소들 사이의 간격
    private Client client;
    private Calendar calendar;
    
    private JPanel dayTimePanel;
    private JPanel nightTimePanel;
    private Calendar lastUpdated = Calendar.getInstance();
    private Timer updateTimer;    // 타이머 객체 생성
    
    private ApplyPanel applyPanel; // ApplyPanel의 참조를 저장

    public CancelPanel(Client client, ApplyPanel applyPanel) {
        this.client = client;
        this.applyPanel = applyPanel;
        calendar = Calendar.getInstance(); // 오늘 날짜 설정
        setLayout(null);

        updateDateLabels(); // 초기에 날짜 레이블 업데이트
    	for(int i = 0; i < 7; i++) {
    		myStatusLabelsDay[i] = " ";
    		myStatusLabelsNight[i] = " ";
    		hasAppliedDay[i] = false;
    		hasAppliedNight[i] = false;
        	hasConfirmedDay[i] = false;
        	hasConfirmedNight[i] = false;
    	}
    	
        // 날짜 라벨 위치 계산
        int dateLabelY = spacing;
        JLabel dateLabel = createLabel(calendar.get(Calendar.YEAR) + "년", 30, (750 - 350) / 2, dateLabelY, 320, 60, false, -1, "");
        add(dateLabel);

        // 주간 패널 위치 계산
        int dayTimePanelY = dateLabelY + 70 + spacing;
        dayTimePanel = createPanel(10, dayTimePanelY, 710, 270);
        setupDayOrNightPanel(dayTimePanel, "주간");
        add(dayTimePanel);

        // 야간 패널 위치 계산
        int nightTimePanelY = dayTimePanelY + 300 + spacing;
        nightTimePanel = createPanel(10, nightTimePanelY, 710, 270);
        setupDayOrNightPanel(nightTimePanel, "야간");
        add(nightTimePanel);
        
        updateTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 새로운 날이 시작되면 날짜 라벨 업데이트
                Calendar now = Calendar.getInstance();
                // 마지막 업데이트 날짜와 현재 날짜가 다른지 확인
                if (!isSameDay(lastUpdated, now)) {
                    updateDateLabels();
                    updatePanels();
                    lastUpdated = now; // 마지막 업데이트 날짜 갱신
                }
                
                // 여기에서 서버로부터 메시지를 확인하고 업데이트할 수 있도록 구현
                String messages = client.getReceivedMessage();
                String[] parts = messages.split("\\|");
            	if(parts[0].equals("POSITION") || parts[0].equals("APPLICATION_DATES") || parts[0].equals("CONFIRM")) {
            		processServerMessage(messages); // 받은 메시지 처리
            	}
                
            }
        });
        updateTimer.start(); // 타이머 시작
    }
    
    // 두 Calendar 인스턴스가 같은 날짜인지 확인하는 메소드
    private boolean isSameDay(Calendar cal1, Calendar cal2) {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }
    
    private void setupDayOrNightPanel(JPanel panel, String dayOrNightLabel) {
        // 주간/야간 라벨 위치 계산
        int labelDayYPosition = spacing;
        JLabel labelDay = createLabel(dayOrNightLabel, 30, 10, labelDayYPosition, 100, 40, false, -1, "");
        panel.add(labelDay);

        int labelWidth = 90;
        int buttonWidth = 90;
        int startOffset = 10;

        int labelYPosition = labelDayYPosition + 40 + spacing;
        int elementHeight = 30;
        int dateLabelHeight = 270 - labelYPosition - (spacing * 3) - (elementHeight * 2);

        for (int i = 0; i < 7; i++) {
            int xPosition = startOffset + i * (labelWidth + spacing);

            JLabel dateLabel = createLabel(dateLabels[i], 14, xPosition, labelYPosition, labelWidth, dateLabelHeight, true, i, dayOrNightLabel);
            panel.add(dateLabel);

            int statusLabelY = labelYPosition + dateLabelHeight + spacing;
            String status = (dayOrNightLabel.equals("주간")) ? myStatusLabelsDay[i] : myStatusLabelsNight[i];
            JLabel statusLabel = createLabel(status, 14, xPosition, statusLabelY, labelWidth, elementHeight, false, -1, "");
            panel.add(statusLabel);

            int buttonY = statusLabelY + elementHeight + spacing;
            JButton button = createButton("취소", xPosition, buttonY, buttonWidth, elementHeight, i, dayOrNightLabel);
            panel.add(button);
        }
    }
    
    
    private void updatePanels() {
        remove(dayTimePanel);
        remove(nightTimePanel);
        
        int dayTimePanelY = 90; // 예시 Y 좌표
        dayTimePanel = createPanel(10, dayTimePanelY, 710, 270);
        setupDayOrNightPanel(dayTimePanel, "주간");
        add(dayTimePanel);

        int nightTimePanelY = 400; // 예시 Y 좌표
        nightTimePanel = createPanel(10, nightTimePanelY, 710, 270);
        setupDayOrNightPanel(nightTimePanel, "야간");
        add(nightTimePanel);
        
        revalidate();
        repaint();
    }
    
    // 브로드캐스트로 온 메시지로 인원이 얼마나 차 있는지 확인하는 상태 라벨 업데이트
    public void processServerMessage(String messages) {
        String[] parts = messages.split("\\|");
        
        if (parts.length >= 16 && parts[0].equals("POSITION")) {
        	String todayDate = parts[1]; // 오늘 날짜
        	if(todayDate.equals(simpleDateLabels[0])) {
                for (int i = 2; i < 9; i++) {	// 일주일 신청했던 날짜(주간)의 나의 상태 정보
                    if (!myStatusLabelsDay[i-2].equals("출근O") && !myStatusLabelsDay[i-2].equals("출근X")) {
                    	myStatusLabelsDay[i-2] = parts[i];
                    }
                }
                
                for (int i = 9; i < 16; i++) {	// 일주일 신청했던 날짜(야간)의 나의 상태 정보
                    if (!myStatusLabelsNight[i-9].equals("출근O") && !myStatusLabelsNight[i-9].equals("출근X")) {
                    	myStatusLabelsNight[i-9] = parts[i];
                    }
                }
        	}
        }
        
        
        if (parts.length > 0 && parts[0].equals("APPLICATION_DATES")) {
            // 기존 신청 및 출근 상태 초기화
            Arrays.fill(hasAppliedDay, false);
            Arrays.fill(hasAppliedNight, false);
            Arrays.fill(hasConfirmedDay, false);
            Arrays.fill(hasConfirmedNight, false);

            for (int i = 1; i < parts.length; i += 3) {
                String date = parts[i];
                String period = parts[i + 1];
                String status = parts[i + 2];
                int dateIndex = Arrays.asList(simpleDateLabels).indexOf(date);
                
                if (dateIndex != -1) {
                    if (period.equals("주간")) {
                        if (status.equals("신청")) {
                            hasAppliedDay[dateIndex] = true;
                        } else if (status.equals("출근O")) {
                            hasConfirmedDay[dateIndex] = true;
                            myStatusLabelsDay[dateIndex] = "출근O"; // 출근 상태 저장
                        }  else if(status.equals("출근X")) {
                            hasConfirmedDay[dateIndex] = true;
                        	myStatusLabelsDay[dateIndex] = "출근X";
                        }
                    } else if (period.equals("야간")) {
                        if (status.equals("신청")) {
                            hasAppliedNight[dateIndex] = true;
                        } else if (status.equals("출근O")) {
                            hasConfirmedNight[dateIndex] = true;
                            myStatusLabelsNight[dateIndex] = "출근O"; // 출근 상태 저장
                        }  else if(status.equals("출근X")) {
                        	hasConfirmedNight[dateIndex] = true;
                        	myStatusLabelsNight[dateIndex] = "출근X";
                        }
                    }
                }
            }
        }
        
        
        if (parts[0].equals("CONFIRM")) {
            for (int i = 1; i < parts.length; i += 3) {
                String date = parts[i];
                String period = parts[i + 1];
                boolean confirmed = Boolean.parseBoolean(parts[i + 2]);
                int dateIndex = Arrays.asList(simpleDateLabels).indexOf(date);

                if ((dateIndex != -1) && (confirmed == true)) {
                    if (period.equals("주간")) {
                        hasConfirmedDay[dateIndex] = true;
                        if(!myStatusLabelsDay[dateIndex].equals("출근O")) {
                            myStatusLabelsDay[dateIndex] = "출근X";
                        }
                    } else {
                        hasConfirmedNight[dateIndex] = true;
                        if(!myStatusLabelsNight[dateIndex].equals("출근O")) {
                        	myStatusLabelsNight[dateIndex] = "출근X";
                        }
                    }
                }
            }
        }
        
        
        updatePanels();
    }

    
    private void updateDateLabels() {
        calendar = Calendar.getInstance(); // Reset to current date

        for (int i = 0; i < 7; i++) {
            int year = calendar.get(Calendar.YEAR); // 현재 calendar의 년도
            int month = calendar.get(Calendar.MONTH) + 1; // 1월 = 0, 따라서 +1
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            String dayOfWeek = new SimpleDateFormat("E").format(calendar.getTime());

            // UI에 표시될 날짜와 요일 (HTML 형식)
            String formattedDate = String.format("<html><div style='text-align: center;'>%02d/%02d<br/><br/>%s</div></html>", month, day, dayOfWeek);
            dateLabels[i] = formattedDate;

            // 서버에 보낼 간단한 날짜 형식
            simpleDateLabels[i] = String.format("%04d/%02d/%02d", year, month, day);

            calendar.add(Calendar.DATE, 1); // 날짜를 하루 증가시킴
        }
    }
    
    
    private JLabel createLabel(String text, int fontSize, int x, int y, int width, int height, boolean isDateLabel, int index, String dayOrNight) {
    	
    	JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font(label.getFont().getName(), Font.PLAIN, fontSize));
        label.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // 경계선 색 변경
        label.setBackground(Color.WHITE); // 배경색 변경
        label.setOpaque(true); // JLabel 배경색 표시
        label.setForeground(Color.DARK_GRAY); // 글자색 변경
        label.setBounds(x, y, width, height);
        
        if (isDateLabel && index >= 0 && index < 7) {
            String status = dayOrNight.equals("주간") ? myStatusLabelsDay[index] : myStatusLabelsNight[index];

            switch (status) {
                case "가확정":
                    label.setBackground(Color.GREEN);
                    break;
                case "예비":
                    label.setBackground(Color.YELLOW);
                    break;
                case "대기":
                    label.setBackground(Color.RED);
                    break;
                case "준비중":
                    label.setBackground(Color.WHITE);
                    break;
                default:
                    label.setBackground(Color.WHITE); // Default background
                    break;
            }
        } else {
            // For non-date labels
            label.setBackground(Color.WHITE); // Default background
        }

        
        switch (text) {
        case "가확정":
            label.setForeground(new Color(0, 128, 0)); // Dark green
            break;
        case "예비":
            label.setForeground(new Color(204, 204, 0)); // Dark yellow
            break;
        case "대기":
            label.setForeground(new Color(139, 0, 0)); // Dark red
            break;
        case "준비중":
            label.setForeground(Color.LIGHT_GRAY);
            break;
        default:
            label.setForeground(Color.BLACK);
            break;
        }
        
        
        return label;
    }
    
    private JButton createButton(String text, int x, int y, int width, int height, int index, String dayOrNight) {
        boolean hasApplied = (dayOrNight.equals("주간")) ? hasAppliedDay[index] : hasAppliedNight[index];
        boolean hasConfirmed = (dayOrNight.equals("주간")) ? hasConfirmedDay[index] : hasConfirmedNight[index];
    	JButton button = new JButton(text);
    	
        button.setBounds(x, y, width, height);
        button.setBackground(new Color(225, 225, 225)); // 버튼 배경색 변경
        button.setForeground(Color.DARK_GRAY); // 버튼 글자색 변경
        button.setFocusPainted(false); // 버튼 포커스 테두리 제거
        button.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        button.setActionCommand(dayOrNight + "|" + index);
        
        if (hasConfirmed) {
            // 출근이 확정된 경우
            button.setText("마감");
            button.setEnabled(false);
        } else {
            // 출근이 확정되지 않은 경우
            button.setEnabled(hasApplied); // 버튼 활성화 상태 설정
            
            // 신청버튼 눌렀을 떄
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (hasApplied) {
                        // 날짜와 주간/야간 정보를 가져옴
                        String[] commandParts = e.getActionCommand().split("\\|");
                        String period = commandParts[0];
                        int dateIndex = Integer.parseInt(commandParts[1]);
                        String date = simpleDateLabels[dateIndex]; // 실제 날짜 정보

                        // 확인 다이얼로그 메시지 생성
                        String confirmMessage = date + " (" + period + ") 취소하기";

                        // 옵션 다이얼로그를 사용하여 사용자에게 확인 요청
                        int choice = JOptionPane.showOptionDialog(
                            null,
                            confirmMessage,
                            "취소확인",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new String[]{"예", "아니오"},
                            "예"
                        );

                        // 사용자가 "예"를 선택한 경우
                        if (choice == JOptionPane.YES_OPTION) {
                            // 취소 완료 메시지를 다이얼로그로 표시
                            JOptionPane.showMessageDialog(
                                null, 
                                "취소 완료!", 
                                "확인", 
                                JOptionPane.INFORMATION_MESSAGE
                            );

                            // 서버에 취소 메시지 보내기
                            String cancelMessage = "CANCEL|" + period + "|" + date;
                            client.sendMessage(cancelMessage);

                            // 서버로부터의 응답을 처리하는 타이머
                            Timer responseTimer = new Timer(100, new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent evt) {
                                    String response = client.getReceivedMessage();
                                    if (response != null && response.equals("CANCEL_SUCCESS")) {
                                        button.setEnabled(false); // 버튼 비활성화
                                        applyPanel.activateApplyButton(response, index, period); // 신청 패널의 버튼을 다시 활성화

                                        // 상태 배열을 업데이트
                                        if(period.equals("주간")) {
                                            hasAppliedDay[dateIndex] = false;
                                        } else {
                                            hasAppliedNight[dateIndex] = false;
                                        }
                                        ((Timer) evt.getSource()).stop();
                                    }
                                }
                            });
                            responseTimer.setRepeats(true);
                            responseTimer.start();
                        }
                    }
                }
            });
            
        }
        
        
        return button;
    }

    
    private JPanel createPanel(int x, int y, int width, int height) {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // 패널 경계선 색 변경
        panel.setBackground(Color.WHITE); // 패널 배경색 변경
        panel.setBounds(x, y, width, height);
        return panel;
    }
    
    
    public void activateCancelButton(String response, int index, String dayOrNight) {
        if (response.equals("APPLY_SUCCESS")) {
            if (dayOrNight.equals("주간")) {
                hasAppliedDay[index] = true;
            } else {
                hasAppliedNight[index] = true;
            }
            updatePanels();
        }
    }
    
    
}




// 화면 구성
public class ClientGUI extends JFrame {
	
	public ClientGUI(Client client) {
		JTabbedPane clientGUI = new JTabbedPane();
		
		MySchedulePanel mySchedulePanel = new MySchedulePanel(client);
		ApplyPanel applyPanel = new ApplyPanel(client);
		CancelPanel cancelPanel = new CancelPanel(client, applyPanel);
		applyPanel.setCancelPanel(cancelPanel);
		MyinfoPanel MyInfoPanel = new MyinfoPanel(client);
		
		clientGUI.addTab("나의일정", mySchedulePanel);
		clientGUI.addTab("내 정보", MyInfoPanel);
		clientGUI.addTab("지원하기", applyPanel);
		clientGUI.addTab("취소하기", cancelPanel);
		
        getContentPane().add(clientGUI);
        setTitle("사용자 화면");
		
		// Frame 설정
        setSize(750, 750);
        setResizable(false); // 프엔
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
	}	

}



