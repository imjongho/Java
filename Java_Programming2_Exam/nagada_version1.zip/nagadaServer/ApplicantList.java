package nagadaServer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import nagadaFront.*;


public class ApplicantList extends JFrame {

    private Server server;
    private DefaultTableModel model; // 멤버 변수로 DefaultTableModel 선언
    private JTextField minField; // min 값 입력 필드
    private JTextField maxField; // max 값 입력 필드

    private String dateLabel;
    private String period;

    public ApplicantList(List<Applicant> applicants, String dateLabel, String period, Server server) {
        super("지원자 관리 - " + dateLabel + " " + period);
        this.server = server;
        this.dateLabel = dateLabel;
        this.period = period;

        setSize(700, 550);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // 변경: EXIT_ON_CLOSE -> DISPOSE_ON_CLOSE, 이 창만 닫기
        setLayout(new BorderLayout(10, 10));

        // 상단 패널 추가
        JPanel topPanel = createDatePanel(dateLabel, period);
        add(topPanel, BorderLayout.NORTH);

        // 중앙 패널 추가 (테이블 포함)
        JPanel tablePanel = createTablePanel(applicants);
        add(tablePanel, BorderLayout.CENTER);

        // 하단 패널 추가
        JPanel bottomPanel = createBottomPanel();
        add(bottomPanel, BorderLayout.SOUTH);
        setResizable(false);
        // 서버에서 해당 날짜와 기간에 대한 최소/최대 인원 수를 가져옵니다.
        Map<String, Integer[]> periodMinMaxValues = server.getDateMinMaxCounts().get(dateLabel);
        if (periodMinMaxValues != null) {
            Integer[] minMax = periodMinMaxValues.get(period);
            if (minMax != null) {
                int min = minMax[0];
                int max = minMax[1];
                updateMinMaxValues(min, max); // 여기서 초기값을 설정합니다.
            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // ApplicantList가 닫힐 때 activeApplicantLists에서 해당 창 제거
                server.getActiveApplicantLists().remove(dateLabel + "|" + period);
            }
        });

    }

    private JPanel createDatePanel(String dateLabel, String period) {
        JPanel datePanel = new JPanel();
        datePanel.setLayout(new BorderLayout());

        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblDate = new JLabel("날짜: " + dateLabel + " (" + period + ")");
        lblDate.setFont(new Font("맑은 고딕", 1, 20));

        leftPanel.add(lblDate);
        datePanel.add(leftPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JLabel requiredPeopleLabel = new JLabel("필요인원:");
        requiredPeopleLabel.setFont(new Font("맑은 고딕", 1, 20));
        rightPanel.add(requiredPeopleLabel);

        minField = createHintTextField("최소", 0, 4);
        maxField = createHintTextField("최대", 0, 4);
        minField.setPreferredSize(new Dimension(60, 25));
        maxField.setPreferredSize(new Dimension(60, 30));

        rightPanel.add(minField);
        rightPanel.add(new JLabel("~"));
        rightPanel.add(maxField);

        ImageIcon Img1 = new ImageIcon("src/nagadaImg/SaveButton1.png");
        ImageIcon Img2 = new ImageIcon("src/nagadaImg/SaveButton2.png");
        JButton btnSave = new JButton(Img1);
        btnSave.setPressedIcon(Img2); // 눌렀을 때의 이미지
        btnSave.setRolloverIcon(Img2); // 버튼에 마우스가 올라갈떄 이미지 변환
        btnSave.setBorderPainted(false); // 버튼 테두리 설정해제
        btnSave.setFocusPainted(false); // 누르면 생기는 테두리 해제
        btnSave.setContentAreaFilled(false);
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경

        btnSave.setPreferredSize(new Dimension(80, 30));

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String minInput = minField.getText().trim();
                String maxInput = maxField.getText().trim();

                // System.out.println("Min Input: " + minInput); // 디버깅을 위해 입력된 문자열 출력
                // System.out.println("Max Input: " + maxInput);

                // 숫자 형식 검증
                if (!minInput.matches("\\d+") || !maxInput.matches("\\d+")) {
                    NagadaJDialog dialog = new NagadaJDialog("문자 오류", "src/nagadaImg/DiaNum.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                    dialog.setVisible(true);
                    return;
                }

                int minCount = Integer.parseInt(minInput);
                int maxCount = Integer.parseInt(maxInput);

                // 최소 인원과 최대 인원은 0 이상이어야 함
                if (minCount < 0 || maxCount < 0) {
                    JOptionPane.showMessageDialog(ApplicantList.this, "최소 인원과 최대 인원을 0 보다 큰 값을 입력하세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 최소 인원은 최대 인원보다 작거나 같아야 함
                if (minCount > maxCount) {
                    JOptionPane.showMessageDialog(ApplicantList.this, "최소 인원은 최대 인원보다 작거나 같아야 합니다.", "입력 오류", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                server.updateDateMinMaxCounts(dateLabel, period, minCount, maxCount);

                NagadaJDialog dialog = new NagadaJDialog("저장 성공", "src/nagadaImg/DiaSave.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                dialog.setVisible(true);

                updateMinMaxValues(minCount, maxCount);

                server.updateAllClientsWithPersonalizedStatus();

            }

        });

        rightPanel.add(btnSave);
        datePanel.add(rightPanel, BorderLayout.EAST);

        return datePanel;
    }


    private JPanel createTablePanel(List<Applicant> applicants) {
        JPanel tablePanel = new JPanel(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"번호", "ID", "이름", "나이", "성별", "전화번호", "점수"}, 0);
        JTable table = new JTable(model);

        table.setDragEnabled(true);
        table.setDropMode(DropMode.INSERT_ROWS);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        table.setFillsViewportHeight(true);

        int sequenceNumber = 1;
        for (Applicant applicant : applicants) {
            model.addRow(new Object[]{sequenceNumber, applicant.getUserId(), applicant.getName(), applicant.getAge(), applicant.getGender(), applicant.getPhoneNumber(), applicant.getScore()});
            sequenceNumber++;
        }

        adjustColumnWidths(table); // Adjust column widths
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // 초기 지원자 데이터 채우기
        updateApplicantList(applicants);

        return tablePanel;
    }

    // 지원자 목록을 업데이트하는 메서드
    public void updateApplicantList(List<Applicant> updatedApplicants) {
        model.setRowCount(0); // 기존 데이터를 모두 지웁니다.

        int sequenceNumber = 1;
        for (Applicant applicant : updatedApplicants) {
            model.addRow(new Object[]{sequenceNumber, applicant.getUserId(), applicant.getName(), applicant.getAge(), applicant.getGender(), applicant.getPhoneNumber(), applicant.getScore()});
            sequenceNumber++;
        }
    }

    private void adjustColumnWidths(JTable table) {
        TableColumn numberColumn = table.getColumnModel().getColumn(0); // 번호 column
        TableColumn idColumn = table.getColumnModel().getColumn(1); // ID column
        TableColumn nameColumn = table.getColumnModel().getColumn(2); // 이름 column
        TableColumn ageColumn = table.getColumnModel().getColumn(3); // 나이 column
        TableColumn genderColumn = table.getColumnModel().getColumn(4); // 성별 column
        TableColumn phoneColumn = table.getColumnModel().getColumn(5); // 전화번호 column
        TableColumn scoreColumn = table.getColumnModel().getColumn(6); // 점수 column

        numberColumn.setPreferredWidth(30); // 번호 열 너비 설정
        idColumn.setPreferredWidth(80); // ID 열 너비 설정
        nameColumn.setPreferredWidth(50); // 이름 열 너비 설정
        ageColumn.setPreferredWidth(50); // 나이 열 너비 설정
        genderColumn.setPreferredWidth(50); // 성별 열 너비 설정
        phoneColumn.setPreferredWidth(120); // 전화번호 열 너비 설정
        scoreColumn.setPreferredWidth(50); // 전화번호 열 너비 설정
    }


    private JPanel createBottomPanel() {
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // 버튼 사이의 간격 조절
        ImageIcon Img1 = new ImageIcon("src/nagadaImg/ModiButton1.png");
        ImageIcon Img2 = new ImageIcon("src/nagadaImg/ModiButton2.png");
        JButton btnModify = new JButton(Img1);
        btnModify.setPressedIcon(Img2); // 눌렀을 때의 이미지
        btnModify.setRolloverIcon(Img2); // 버튼에 마우스가 올라갈떄 이미지 변환
        btnModify.setBorderPainted(false); // 버튼 테두리 설정해제
        btnModify.setFocusPainted(false); // 누르면 생기는 테두리 해제
        btnModify.setContentAreaFilled(false);
        btnModify.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경
        btnModify.setPreferredSize(new Dimension(130, 50)); // 버튼 크기 조절

        btnModify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                prioritizeApplicant();
            }
        });


        ImageIcon Img3 = new ImageIcon("src/nagadaImg/DoneButton1.png");
        ImageIcon Img4 = new ImageIcon("src/nagadaImg/DoneButton2.png");
        JButton btnConfirm = new JButton(Img3);
        btnConfirm.setPressedIcon(Img4); // 눌렀을 때의 이미지
        btnConfirm.setRolloverIcon(Img4); // 버튼에 마우스가 올라갈떄 이미지 변환
        btnConfirm.setBorderPainted(false); // 버튼 테두리 설정해제
        btnConfirm.setFocusPainted(false); // 누르면 생기는 테두리 해제
        btnConfirm.setContentAreaFilled(false);
        btnConfirm.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경
        btnConfirm.setPreferredSize(new Dimension(130, 50)); // 버튼 크기 조절

        // btnConfirm 이벤트 리스너 부분
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog(ApplicantList.this, "최종 확정할 인원 수를 입력하세요:");

                if (input != null && input.matches("\\d+")) {
                    int confirmedCount = Integer.parseInt(input);
                    List<String> finalConfirmedApplicants = confirmApplicants(confirmedCount);

                    // 메시지 전송 후 대기 없이 즉시 다음 메시지 전송
                    server.sendInitialApplicationStatusToAllClients();
                    // 별도 스레드에서 딜레이 후 두 번째 메시지 전송
                    new Thread(() -> {
                        try {
                            Thread.sleep(1500); // 2초 대기
                            server.sendConfirmedStatusToAllClients();
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        } finally {
                            // 작업이 완료되면 버튼 다시 활성화
                            btnConfirm.setEnabled(true);
                        }
                    }).start();
                } else {
                    JOptionPane.showMessageDialog(ApplicantList.this, "유효한 숫자를 입력해야 합니다.", "입력 오류", JOptionPane.ERROR_MESSAGE);
                    btnConfirm.setEnabled(true);
                }
            }
        });

        bottomPanel.add(btnModify);
        bottomPanel.add(btnConfirm);

        return bottomPanel;
    }


    private JTextField createHintTextField(String hint, int defaultValue, int columns) {
        JTextField textField = new JTextField(hint, columns);
        textField.setMaximumSize(new Dimension(200, 40));
        textField.setFont(new Font("맑은 고딕", 1, 24));

        // 초기 텍스트 설정
        if (defaultValue == 0) {
            textField.setForeground(Color.GRAY);
        } else {
            textField.setForeground(Color.BLACK);
        }

        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(hint)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setText(hint);
                    textField.setForeground(Color.GRAY);
                }
            }
        });

        return textField;
    }


    public void updateMinMaxValues(int min, int max) {
        if (min == 0 && max == 0) {
            // 아직 값이 설정되지 않았을 경우
            minField.setText("최소");
            maxField.setText("최대");
        } else {
            // 값이 설정되어 있을 경우
            minField.setText(String.valueOf(min));
            maxField.setText(String.valueOf(max));
        }
    }


    // 순서 변경 메서드 구현
    private void changeApplicantOrder() {
        int rowCount = model.getRowCount();
        List<String> newOrder = new ArrayList<>();
        for (int i = 0; i < rowCount; i++) {
            newOrder.add(model.getValueAt(i, 1).toString()); // 1번 인덱스는 사용자 ID
        }
        server.updateApplicantOrder(dateLabel, period, newOrder);
        server.updateAllClientsWithPersonalizedStatus(); // 클라이언트에게 메시지 보냄
    }


    private void prioritizeApplicant() {
        // 사용자에게 ID 입력 요청
        String applicantId = JOptionPane.showInputDialog(this, "우선 순위를 높일 지원자의 ID를 입력하세요:", "지원자 우선 순위 설정", JOptionPane.QUESTION_MESSAGE);

        if (applicantId != null && !applicantId.trim().isEmpty()) {
            // 입력받은 ID로 지원자 찾기
            int rowIndex = findApplicantRowById(applicantId.trim());

            if (rowIndex != -1) {
                // 지원자를 목록의 맨 위로 이동
                moveApplicantToTop(rowIndex);
                JOptionPane.showMessageDialog(this, "지원자 순서가 수정되었습니다.");
                changeApplicantOrder();    // 저장
            } else {
                JOptionPane.showMessageDialog(this, "입력한 ID를 가진 지원자가 목록에 없습니다.", "오류", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private int findApplicantRowById(String applicantId) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 1).equals(applicantId)) {
                return i;
            }
        }
        return -1; // 찾지 못했으면 -1 반환
    }

    private void moveApplicantToTop(int rowIndex) {
        // 해당 행의 데이터를 가져온 후 삭제
        Object[] rowData = new Object[model.getColumnCount()];
        for (int i = 0; i < model.getColumnCount(); i++) {
            rowData[i] = model.getValueAt(rowIndex, i);
        }
        model.removeRow(rowIndex);

        // 데이터를 테이블의 맨 위에 추가
        model.insertRow(0, rowData);

        // 시퀀스 번호 업데이트
        updateSequenceNumbers();
    }


    private void updateSequenceNumbers() {
        for (int i = 0; i < model.getRowCount(); i++) {
            model.setValueAt(i + 1, i, 0); // 첫 번째 열(시퀀스 번호)를 업데이트
        }
    }


    private List<String> confirmApplicants(int count) {
        List<String> confirmedApplicants = new ArrayList<>();
        List<String> unconfirmedApplicants = new ArrayList<>();

        // 확정된 지원자가 있는 경우
        if (count > 0) {
            for (int i = 0; i < count && i < model.getRowCount(); i++) {
                String userId = model.getValueAt(i, 1).toString();
                confirmedApplicants.add(userId);
                server.updateUserApplicationStatus(userId, dateLabel, period, "출근O"); // 서버에 출근 상태 업데이트 요청
            }

            // 점수 증가 로직
            server.increaseScoreForConfirmedUsers(confirmedApplicants);
        }

        // Collect IDs of unconfirmed applicants
        for (int i = count; i < model.getRowCount(); i++) {
            String userId = model.getValueAt(i, 1).toString();
            unconfirmedApplicants.add(userId);
            server.updateUserApplicationStatus(userId, dateLabel, period, "출근X");
        }

        // 확정되지 않은 지원자 제거
        removeUnconfirmedApplicants(count);
        server.removeUnconfirmedApplicantsFromLists(dateLabel, period, unconfirmedApplicants);

        // 해당 날짜와 시간대에 대한 확정 상태 업데이트
        server.updateConfirmedStatus(dateLabel, period, true);
        return confirmedApplicants;
    }


    // 확정되지 않은 지원자를 테이블에서 제거하는 메서드
    private void removeUnconfirmedApplicants(int confirmedCount) {
        // 뒤에서부터 제거하여 인덱스 문제를 방지
        for (int i = model.getRowCount() - 1; i >= confirmedCount; i--) {
            model.removeRow(i);
        }
    }


}







