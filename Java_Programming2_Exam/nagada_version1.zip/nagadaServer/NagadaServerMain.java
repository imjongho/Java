package nagadaServer;

public class NagadaServerMain {
	public static void main(String[] args) {
		new Server();
	}
}


