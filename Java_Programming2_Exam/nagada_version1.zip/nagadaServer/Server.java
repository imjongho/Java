package nagadaServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Comparator;


public class Server {

    ServerSocket serverSocket;    // 서버소켓
    static final int PORT = 8000;    // 포트번호
    Socket childSocket;    // 자식스레드에게 넘겨줄 소켓

    // 여러 클라이언트를 동시에 처리하기 위해서 리스트 생성해서 연결된 클라이언트 저장
    List<ChildThread> childList = new ArrayList<>();
    
    // 스케줄러를 선언
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    // 날짜별 주간 및 야간 지원자 명단 관리 맵
    private Map<String, List<String>> dayApplicantNames = new HashMap<>();
    private Map<String, List<String>> nightApplicantNames = new HashMap<>();

    // 날짜별 주간 및 야간 지원자 수 관리 맵
    private Map<String, Integer> dayApplicantCounts = new HashMap<>();
    private Map<String, Integer> nightApplicantCounts = new HashMap<>();

    // 사용자별 신청 정보 저장
    private Map<String, List<String>> userApplications = new HashMap<>();

    // 날짜별 최소 인원과 최대 인원 저장(주간, 야간)
    private Map<String, Map<String, Integer[]>> dateMinMaxCounts = new HashMap<>();

    private Map<String, ApplicantList> activeApplicantLists = new HashMap<>();

    // 날짜별 주간 및 야간 확정 여부를 저장하는 맵
    private Map<String, Map<String, Boolean>> dateConfirmedStatus = new HashMap<>();

    private ServerGUI serverGUI;

    Connection conn;
    String url = "jdbc:mysql://localhost:3306/nagada?serverTimezone=UTC";

    String databaseID = "root";
    String databasePW = "jongho4502@";

    Statement stmt;
    ResultSet result;

    // 생성자
    public Server() {

        new LoginGUI(this);        // 서버 열기 전 관리자 로그인 실행

        try {
            serverSocket = new ServerSocket(PORT);    // 서버 열기
            System.out.println("서버가 열림");
            startPeriodicBroadcast();    // 주기적으로 브로드캐스트 시작
            initialize(); // 서버 시작 시 초기화 호출
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }

        while (true) {
            try {
                childSocket = serverSocket.accept();    // accept -> 1. 소켓 접속 대기, 2. 소켓 접속 허락

                ChildThread childThread = new ChildThread(childSocket, this);
                addClient(childThread);

                Thread t = new Thread(childThread);
                t.start();    // 자식 스레드 실행

            } catch (Exception e) {
                e.printStackTrace();
                stopServer();
                System.exit(0);
            }
        }

    }


    // 로그인 성공 시 호출되는 메소드
    public void onLoginSuccess() {
        serverGUI = new ServerGUI(this); // 로그인 성공 후 ServerGUI 생성 및 표시
        serverGUI.setVisible(true);
    }


    // **********브로드캐스트**********
    private String classifyApplicantStatus(int dayIndex, String period) {
        String dayKey = getDayKey(dayIndex);
        Map<String, Integer> applicantCounts = (period.equals("주간")) ? dayApplicantCounts : nightApplicantCounts;
        Map<String, Integer[]> periodMinMaxCounts = dateMinMaxCounts.getOrDefault(dayKey, new HashMap<>());
        Integer[] minMax = periodMinMaxCounts.getOrDefault(period, new Integer[]{0, 0});
        int applicantCount = applicantCounts.getOrDefault(dayKey, 0);
        int minCount = minMax[0];
        int maxCount = minMax[1];

        // 최소 및 최대 인원이 설정되지 않았을 경우 '준비중' 반환
        if (minCount == 0 && maxCount == 0) {
            return "준비중";
        }

        if (applicantCount < minCount) {
            return "미만";
        } else if (applicantCount >= minCount && applicantCount <= maxCount) {
            return "충족";
        } else {
            return "초과";
        }
    }

    // 주기적인 브로드캐스트
    public void startPeriodicBroadcast() {
        final Runnable broadcaster = new Runnable() {
            public void run() {
                generateAndBroadcastMessage();
            }
        };
        scheduler.scheduleAtFixedRate(broadcaster, 0, 60, TimeUnit.SECONDS);
    }


    // 브로드캐스트 메시지 생성 및 전송
    public void generateAndBroadcastMessage() {
        LocalDate today = LocalDate.now();
        StringBuilder message = new StringBuilder(today.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));

        for (int i = 0; i < 7; i++) {
            message.append("|").append(classifyApplicantStatus(i, "주간"));
        }

        for (int i = 0; i < 7; i++) {
            message.append("|").append(classifyApplicantStatus(i, "야간"));
        }

        broadcast(message.toString());
    }


    // 개별 클라이언트에게만 메시지를 보내는 메서드
    public void generateAndSendMessageToClient(ChildThread client) {
        LocalDate today = LocalDate.now();
        StringBuilder message = new StringBuilder(today.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));

        for (int i = 0; i < 7; i++) {
            message.append("|").append(classifyApplicantStatus(i, "주간"));
        }

        for (int i = 0; i < 7; i++) {
            message.append("|").append(classifyApplicantStatus(i, "야간"));
        }

        // 특정 클라이언트에게만 메시지를 전송
        client.sendMessage("BROADCAST|" + message.toString());
    }


    private String getDayKey(int dayIndex) {
        LocalDate today = LocalDate.now();
        LocalDate targetDate = today.plusDays(dayIndex);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        return targetDate.format(formatter);
    }


    public void sendPersonalizedStatus(ChildThread client) {
        String userId = client.getUserID();
        String personalizedMessage = generateStatusMessageForUser(userId);
        client.sendMessage("POSITION|" + personalizedMessage);
    }


    private String generateStatusMessageForUser(String userId) {
        StringBuilder statusMessage = new StringBuilder();
        LocalDate today = LocalDate.now(); // Get today's date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");

        // Append today's date as the starting date of the status message
        statusMessage.append(today.format(formatter));
        for (int i = 0; i < 7; i++) {
            String dayStatus = getUserDayStatus(userId, i, "주간");
            statusMessage.append("|").append(dayStatus);
        }

        for (int i = 0; i < 7; i++) {
            String nightStatus = getUserDayStatus(userId, i, "야간");
            statusMessage.append("|").append(nightStatus);
        }

        return statusMessage.toString();
    }


    // 날짜와 주야간에 따른 최소/최대 인원을 업데이트하는 메소드
    public synchronized void updateDateMinMaxCounts(String date, String period, int newMinCount, int newMaxCount) {
        Map<String, Integer[]> periodMinMaxCounts = dateMinMaxCounts.computeIfAbsent(date, k -> new HashMap<>());
        periodMinMaxCounts.put(period, new Integer[]{newMinCount, newMaxCount});
    }


    public Map<String, Map<String, Integer[]>> getDateMinMaxCounts() {
        return dateMinMaxCounts;
    }


    private String getUserDayStatus(String userId, int dayIndex, String period) {
        Map<String, List<String>> applicantNames = (period.equals("주간")) ? dayApplicantNames : nightApplicantNames;

        String dayKey = getDayKey(dayIndex);
        Map<String, Integer[]> periodMinMaxCounts = dateMinMaxCounts.getOrDefault(dayKey, new HashMap<>());
        Integer[] minMax = periodMinMaxCounts.getOrDefault(period, new Integer[]{0, 0});
        int minCount = minMax[0];
        int maxCount = minMax[1];

        // 해당 날짜에 지원한 사람들이 누구인지
        List<String> applicants = applicantNames.getOrDefault(dayKey, new ArrayList<>());
        int position = applicants.indexOf(userId);


        // 사용자의 상태 결정
        if (position == -1) {
            return " ";
        } else if (minCount == 0 && maxCount == 0) {    // 최소 및 최대 인원이 설정되지 않았을 경우 '준비중' 반환
            return "준비중";
        } else if (position >= 0 && position < minCount) {
            return "가확정";
        } else if (position >= minCount && position < maxCount) {
            return "예비";
        } else {
            return "대기";
        }
    }


    public void updateAllClientsWithPersonalizedStatus() {
        synchronized (childList) {
            for (ChildThread client : childList) {
                sendPersonalizedStatus(client);
            }
        }
    }


    // 서버 종료 시 호출해야 하는 메소드
    public void stopServer() {
        scheduler.shutdownNow();
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private int fetchScore(String userId) {
        try (Connection conn = DriverManager.getConnection(url, databaseID, databasePW);
             PreparedStatement pstmt = conn.prepareStatement("SELECT score FROM user WHERE id = ?")) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("score");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


    // 신청하기 처리 메소드
    public void processAddApplication(String period, String date, String userId) {
        // 명단에 지원자 추가 및 지원자 수 증가는 동기화된 블록 내에서 수행
        synchronized (this) {
            List<String> applicantIds;
            Map<String, Integer> applicantCounts;

            if ("주간".equals(period)) {
                applicantIds = dayApplicantNames.computeIfAbsent(date, k -> new ArrayList<>());
                applicantCounts = dayApplicantCounts;
            } else {
                applicantIds = nightApplicantNames.computeIfAbsent(date, k -> new ArrayList<>());
                applicantCounts = nightApplicantCounts;
            }
            userApplications.computeIfAbsent(userId, k -> new ArrayList<>()).add(date + "|" + period + "|신청");

            int applicantScore = fetchScore(userId);
            
            int insertIndex = 0;
            for (String id : applicantIds) {
                int currentScore = fetchScore(id);
                if (applicantScore > currentScore) {
                    break;
                }
                insertIndex++;
            }

            applicantIds.add(insertIndex, userId);
            int newCount = applicantCounts.getOrDefault(date, 0) + 1;
            applicantCounts.put(date, newCount);

            // GUI 업데이트
            updateApplicantNumbers(date, period, newCount);
            // 지원자 정보 업데이트
            updateApplicantListUI(date, period);

        }
    }


    // 지원 취소 처리 메소드
    public void processDeleteApplication(String period, String date, String userId) {
        synchronized (this) {
            List<String> applicantIds;
            Map<String, Integer> applicantCounts;

            if ("주간".equals(period)) {
                applicantIds = dayApplicantNames.getOrDefault(date, new ArrayList<>());
                applicantCounts = dayApplicantCounts;
            } else {
                applicantIds = nightApplicantNames.getOrDefault(date, new ArrayList<>());
                applicantCounts = nightApplicantCounts;
            }
            userApplications.getOrDefault(userId, new ArrayList<>()).remove(date + "|" + period + "|신청");

            // 지원자 명단에서 사용자 ID 제거
            applicantIds.remove(userId);

            // 지원자 수 감소
            int newCount = applicantCounts.getOrDefault(date, 0) - 1;
            newCount = Math.max(newCount, 0); // 음수가 되지 않도록 보장
            applicantCounts.put(date, newCount);

            // GUI 업데이트
            updateApplicantNumbers(date, period, newCount);

            // 지원자 정보 업데이트
            updateApplicantListUI(date, period);
        }
    }


    // 지원자 정보 UI 업데이트 메소드
    private void updateApplicantListUI(String date, String period) {
        ApplicantList applicantList = serverGUI.getApplicantList(date, period);
        if (applicantList != null) {
            List<Applicant> updatedApplicants = getApplicant(getApplicantIds(date, period));
            applicantList.updateApplicantList(updatedApplicants);
        }
    }


    public Map<String, ApplicantList> getActiveApplicantLists() {
        return this.activeApplicantLists;
    }

    // 지원자 수 업데이트 및 GUI 업데이트 메소드
    public void updateApplicantNumbers(String date, String period, int count) {
        Map<String, Integer> applicantCounts = period.equals("주간") ? dayApplicantCounts : nightApplicantCounts;
        applicantCounts.put(date, count);
        serverGUI.updateApplicantNumbers(dayApplicantCounts, nightApplicantCounts);
        serverGUI.updatePanels();
    }


    // 상세보기 기능을 위한 메서드
    public void showApplicantDetails(String date, String period) {
        String key = date + "|" + period;
        List<String> applicantIds = getApplicantIds(date, period);
        List<Applicant> detailsList = getApplicant(applicantIds);

        if (activeApplicantLists.containsKey(key)) {
            // 이미 존재하는 ApplicantList 창 업데이트
            ApplicantList existingApplicantList = activeApplicantLists.get(key);
            existingApplicantList.updateApplicantList(detailsList);
            existingApplicantList.toFront(); // 창을 맨 앞으로 가져옵니다.
        } else {
            // 새로운 ApplicantList 창 생성 및 맵에 추가
            ApplicantList newApplicantList = new ApplicantList(detailsList, date, period, this);
            activeApplicantLists.put(key, newApplicantList);
        }
    }

    // 해당 날짜와 주야간에 따른 userId 목록을 가져오는 메서드
    private List<String> getApplicantIds(String date, String period) {
        Map<String, List<String>> applicantMap = period.equals("주간") ? dayApplicantNames : nightApplicantNames;
        return applicantMap.getOrDefault(date, new ArrayList<>());
    }

    // 데이터베이스에서 userId에 해당하는 상세 정보를 가져오는 메서드
    private List<Applicant> getApplicant(List<String> userIds) {
        List<Applicant> detailsList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, databaseID, databasePW);
            System.out.println("DB연결완료");

            // 각 userId에 대해 정보 검색
            for (String userId : userIds) {
                String query = "SELECT name, age, gender, phone, score FROM user WHERE id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, userId);
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    String name = rs.getString("name");
                    String age = rs.getString("age");
                    String gender = rs.getString("gender");
                    String phone = rs.getString("phone");
                    int score = rs.getInt("score"); // 점수 가져오기

                    detailsList.add(new Applicant(userId, name, age, gender, phone, score));
                }
            }

        } catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버 로드 오류");
        } catch (SQLException e) {
            System.out.println("DB 연결 오류");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return detailsList;
    }


    // 모든 클라이언트에게 개별적인 신청 상태 메시지를 전송하는 메서드
    public void sendInitialApplicationStatusToAllClients() {
        synchronized (childList) {
            for (ChildThread client : childList) {
                String userId = client.getUserID();
                List<String> userAppList = new ArrayList<>(userApplications.getOrDefault(userId, new ArrayList<>()));

                // 날짜 정렬
                Collections.sort(userAppList);

                // 사용자별 신청 상태 메시지 생성
                String statusMessage = generateInitialStatusMessage(userAppList);

                // 해당 클라이언트에게 메시지 전송
                client.sendMessage("APPLICATION_DATES|" + statusMessage);
            }
        }
    }

    // 클라이언트 연결 시 사용자의 신청 상태를 전송하는 메서드
    public void sendInitialApplicationStatus(ChildThread client) {
        String userId = client.getUserID();
        List<String> userAppList = new ArrayList<>(userApplications.getOrDefault(userId, new ArrayList<>()));

        // 날짜를 정렬합니다.
        Collections.sort(userAppList);

        // 정렬된 날짜 목록을 문자열로 변환하여 전송합니다.
        String statusMessage = generateInitialStatusMessage(userAppList);
        client.sendMessage("APPLICATION_DATES|" + statusMessage);
    }


    // 사용자의 초기 신청 상태 메시지 생성
    private String generateInitialStatusMessage(List<String> userAppList) {
        StringBuilder statusMessage = new StringBuilder();

        // 각 신청 날짜를 문자열로 변환합니다.
        for (String application : userAppList) {
            statusMessage.append(application).append("|"); // 각 신청을 세미콜론으로 구분
        }

        return statusMessage.toString();
    }


    // 모든 클라이언트에게 내용 전달
    public synchronized void broadcast(String message) {
        // 연결된 클라이언트들에게 모두 보냄
        for (int i = 0; i < childList.size(); i++) {
            ChildThread child = (ChildThread) childList.get(i);
            child.sendMessage("BROADCAST|" + message);
        }
    }


    // 클라이언트가 퇴장 시 호출되며, 리스트에 클라이언트 담당 쓰레드 제거
    public synchronized void removeClient(ChildThread child) {
        childList.remove(child);
        System.out.println(childSocket.getInetAddress() + "님이 종료");
        System.out.println("현재 인원 : " + childList.size() + "명");
    }


    // 클라이언트 입장 시 호출되며, 리스트에 클라이언트 담당 쓰레드 저장
    public synchronized void addClient(ChildThread child) {
        // 리스트에 ChildThread 객체 저장
        childList.add(child);
        System.out.println(childSocket.getInetAddress() + "님이 접속");
        System.out.println("현재 인원 : " + childList.size() + "명");
    }


    // 서버 생성자 내부에서 호출할 초기화 메서드 추가
    private void initialize() {
        LocalDate today = LocalDate.now();
        for (int i = 0; i < 365; i++) { // 1년치 날짜 초기화
            LocalDate date = today.plusDays(i);
            String formattedDate = date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));

            // 지원자 수 초기화
            dayApplicantCounts.put(formattedDate, 0);
            nightApplicantCounts.put(formattedDate, 0);

            // min, max 값 초기화
            Map<String, Integer[]> minMaxCounts = new HashMap<>();
            minMaxCounts.put("주간", new Integer[]{0, 0});
            minMaxCounts.put("야간", new Integer[]{0, 0});
            dateMinMaxCounts.put(formattedDate, minMaxCounts);

            // 확정 상태 초기화
            // 주간 및 야간 확정 상태 초기화
            Map<String, Boolean> confirmedStatus = new HashMap<>();
            confirmedStatus.put("주간", false);
            confirmedStatus.put("야간", false);
            dateConfirmedStatus.put(formattedDate, confirmedStatus);
        }

    }


    public synchronized void updateApplicantOrder(String date, String period, List<String> newOrder) {
        Map<String, List<String>> applicantNames = period.equals("주간") ? dayApplicantNames : nightApplicantNames;
        applicantNames.put(date, new ArrayList<>(newOrder));
    }


    public synchronized void updateUserApplicationStatus(String userId, String date, String period, String status) {
        List<String> applications = userApplications.getOrDefault(userId, new ArrayList<>());
        // 기존의 신청 기록을 찾아 상태를 업데이트합니다.
        for (int i = 0; i < applications.size(); i++) {
            String application = applications.get(i);
            if (application.startsWith(date + "|" + period)) {
                applications.set(i, date + "|" + period + "|" + status);
                break;
            }
        }

        System.out.println(applications);
    }


    // 날짜별 확정 상태 업데이트 메서드
    public synchronized void updateConfirmedStatus(String date, String period, boolean status) {
        if (dateConfirmedStatus.containsKey(date)) {
            Map<String, Boolean> confirmedStatus = dateConfirmedStatus.get(date);
            confirmedStatus.put(period, status);
        }
    }

    // 클라이언트에게 주간 및 야간 확정 상태를 전송하는 메서드
    public void sendConfirmedStatusToClient(ChildThread client) {
        LocalDate today = LocalDate.now();
        StringBuilder message = new StringBuilder("CONFIRM");

        // 오늘부터 7일간의 날짜에 대한 확정 여부 확인 및 전송
        for (int i = 0; i < 7; i++) {
            LocalDate targetDate = today.plusDays(i);
            String dateKey = targetDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));

            boolean dayConfirmed = isDateConfirmed(dateKey, "주간");
            boolean nightConfirmed = isDateConfirmed(dateKey, "야간");

            message.append("|").append(dateKey).append("|주간|").append(dayConfirmed);
            message.append("|").append(dateKey).append("|야간|").append(nightConfirmed);
        }

        client.sendMessage(message.toString());
    }

    // 모든 클라이언트에게 확정 상태 메시지 전송
    public void sendConfirmedStatusToAllClients() {
        synchronized (childList) {
            for (ChildThread client : childList) {
                sendConfirmedStatusToClient(client);
            }
        }
    }

    // 날짜별 확정 상태 확인 메서드
    public boolean isDateConfirmed(String date, String period) {
        if (dateConfirmedStatus.containsKey(date)) {
            Map<String, Boolean> confirmedStatus = dateConfirmedStatus.get(date);
            return confirmedStatus.getOrDefault(period, false);
        }
        return false;
    }


    // 확정된 사용자들의 점수를 증가시키는 메소드
    public void increaseScoreForConfirmedUsers(List<String> userIds) {
        try (Connection conn = DriverManager.getConnection(url, databaseID, databasePW)) {
            for (String userId : userIds) {
                String sql = "UPDATE user SET score = score + 1 WHERE id = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, userId);
                    pstmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // 확정되지 않은 지원자 명단에서 제거하는 메소드
    public synchronized void removeUnconfirmedApplicantsFromLists(String date, String period, List<String> unconfirmedUserIds) {
        Map<String, List<String>> applicantNames = period.equals("주간") ? dayApplicantNames : nightApplicantNames;
        Map<String, Integer> applicantCounts = period.equals("주간") ? dayApplicantCounts : nightApplicantCounts;
        List<String> applicants = applicantNames.getOrDefault(date, new ArrayList<>());

        applicants.removeAll(unconfirmedUserIds);
        applicantNames.put(date, applicants);

        int newCount = Math.max(applicantCounts.getOrDefault(date, 0) - unconfirmedUserIds.size(), 0);
        applicantCounts.put(date, newCount);

        // GUI 업데이트
        updateApplicantNumbers(date, period, newCount);

        // 지원자 정보 업데이트
        updateApplicantListUI(date, period);
    }


    // 날짜별 확정 상태 업데이트 메서드
    public synchronized void updateUnConfirmedStatus(String date, String period, boolean status) {
        if (dateConfirmedStatus.containsKey(date)) {
            Map<String, Boolean> confirmedStatus = dateConfirmedStatus.get(date);
            confirmedStatus.put(period, status);
        }
    }

}










