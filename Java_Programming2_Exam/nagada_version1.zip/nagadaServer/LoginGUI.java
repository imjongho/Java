package nagadaServer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import nagadaFront.*;

class BackgroundPanel extends JPanel {
    ImageIcon image;

    public BackgroundPanel(String imagePath) {
        image = new ImageIcon(imagePath);
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), this);
    }
}

public class LoginGUI extends JFrame {

    private JTextField textID;
    private JPasswordField textPW;
    private JButton buttonLogin;
    private JButton buttonSignUp;
    private Server server;
    private BackgroundPanel backgroundPanel;

    Connection conn;
    String url = "jdbc:mysql://localhost:3306/nagada?serverTimezone=UTC";

    String databaseID = "root";
    String databasePW = "jongho4502@";

    Statement stmt;
    ResultSet result;

    public LoginGUI(Server server) {
        super("관리자 로그인 화면");
        this.server = server;

        textID = new JTextField("");
        textID.setBorder(null);
        textID.setOpaque(false);
        textPW = new JPasswordField("");
        textPW.setBorder(null);
        textPW.setOpaque(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        backgroundPanel = new BackgroundPanel("src/nagadaImg/Login.png");
        backgroundPanel.setLayout(null);
        setContentPane(backgroundPanel);

    
        JLabel labelNAGADA = new JLabel(" ");
        JLabel labelID = new JLabel();
        JLabel labelPW = new JLabel();
        Font font = new Font("맑은 고딕", 1, 28);
        textID.setFont(font);
        textPW.setFont(font);
        ImageIcon LoginImg = new ImageIcon("src/nagadaImg/LoginButton1.png");
        ImageIcon LoginImg2 = new ImageIcon("src/nagadaImg/LoginButton2.png");
        ImageIcon SignImg = new ImageIcon("src/nagadaImg/JoinButton1.png");
        ImageIcon SignImg2 = new ImageIcon("src/nagadaImg/JoinButton2.png");

        buttonLogin = new JButton(LoginImg);
        buttonLogin.setPressedIcon(LoginImg2); // 눌렀을 때의 이미지
        buttonLogin.setRolloverIcon(LoginImg2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonLogin.setBorderPainted(false); // 버튼 테두리 설정해제
        buttonLogin.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonLogin.setContentAreaFilled(false);

        buttonSignUp = new JButton(SignImg);
        buttonSignUp.setRolloverIcon(SignImg2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonSignUp.setBorderPainted(false);
        buttonSignUp.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonSignUp.setPressedIcon(SignImg2); // 눌렀을 때의 이미지
        buttonSignUp.setContentAreaFilled(false);

        buttonLogin.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경
        buttonSignUp.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경


        // "나가다" 레이블
        labelNAGADA.setBounds(120, 130, 285, 60);

        // ID 레이블과 입력 필드

        labelID.setBounds(75, 262, 80, 40);
        textID.setBounds(188, 259, 280, 50);

        // PW 레이블과 입력 필드

        labelPW.setBounds(75, 370, 80, 40);
        textPW.setBounds(188, 367, 280, 50);

        // 로그인 버튼과 회원가입 버튼
        buttonLogin.setBounds(87, 460, 190, 68);
        buttonSignUp.setBounds(290, 460, 190, 68); // 185 65

        add(labelNAGADA);
        add(labelID);
        add(textID);
        add(labelPW);
        add(textPW);
        add(buttonLogin);
        add(buttonSignUp);

        setSize(550, 666);
        setResizable(false); // 프엔
        setLocationRelativeTo(null);
        setVisible(true);

        addListeners();
    }


    public void addListeners() {

        // 로그인 버튼 눌렀을 때
        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String enteredID = textID.getText();
                char[] enteredPW = textPW.getPassword();
                String enteredPWString = new String(enteredPW);

                if (!enteredID.isEmpty() && enteredPW.length > 0) {

                    try {
                        // JDBC 드라이버 로드 및 데이터베이스 연결
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        conn = DriverManager.getConnection(url, databaseID, databasePW);
                        System.out.println("DB연결완료");

                        // SQL 쿼리 실행
                        stmt = conn.createStatement();
                        String query = "SELECT * FROM user WHERE id = '" + enteredID + "' AND pw = '" + enteredPWString + "' AND position = '관리자'";
                        result = stmt.executeQuery(query);

                        boolean loginSuccessful = false;
                        if (result.next()) {
                            loginSuccessful = true; // 관리자 계정이 테이블에 존재하는 경우
                            System.out.println("MANAGER_LOGIN_SUCCESS");
                        } else {
                            System.out.println("MANAGER_LOGIN_FAIL");
                        }

                        // 로그인 결과에 따른 UI 피드백
                        if (loginSuccessful) {
                            NagadaJDialog dialog = new NagadaJDialog("로그인 성공", "src/nagadaImg/DiaLogin.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png");
                            dialog.setVisible(true);
                            setVisible(false);
                            server.onLoginSuccess();
                        } else {
                            NagadaJDialog dialog = new NagadaJDialog("로그인 실패", "src/nagadaImg/DiaError.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png");
                            dialog.setVisible(true);
                        }

                        // 자원 해제
                        result.close();
                        stmt.close();
                        conn.close();

                    } catch (ClassNotFoundException ex) {
                        System.out.println("JDBC 드라이버 로드 오류");
                    } catch (SQLException ex) {
                        System.out.println("DB 연결 오류");
                    }

                } else {
                    NagadaJDialog dialog = new NagadaJDialog("빈 칸 오류", "src/nagadaImg/DiaNoIDPW.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png");
                    dialog.setVisible(true);
                }
            }
        });


        // 회원가입 버튼 눌렀을 때
        buttonSignUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                JoinGUI joinGUI = new JoinGUI(server);
                joinGUI.setVisible(true);
            }
        });
    }


}


