package nagadaClient;

public class NagadaClientMain {
    public static void main(String[] args) {
        new Client("LocalHost", 8000);
    }

}


