package nagadaClient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import nagadaFront.NagadaJDialog;

class BackgroundPanel extends JPanel {
    ImageIcon image;

    public BackgroundPanel(String imagePath) {
        image = new ImageIcon(imagePath);
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), this);
    }
}

public class LoginGUI extends JFrame {

    private JTextField textID;
    private JPasswordField textPW;
    private JButton buttonLogin;
    private JButton buttonSignUp;
    private BackgroundPanel backgroundPanel;
    private Client client;

    public LoginGUI(Client client) {
        super("사용자 로그인 화면");
        textID = new JTextField("");
        textID.setBorder(null);
        textID.setOpaque(false);
        textPW = new JPasswordField("");
        textPW.setBorder(null);
        textPW.setOpaque(false);
        this.client = client;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        backgroundPanel = new BackgroundPanel("src/nagadaImg/Login.png");
        backgroundPanel.setLayout(null);
        setContentPane(backgroundPanel);


        JLabel labelNAGADA = new JLabel(" ");
        JLabel labelID = new JLabel();
        JLabel labelPW = new JLabel();
        Font font = new Font("맑은 고딕", 1, 28);
        textID.setFont(font);
        textPW.setFont(font);
        ImageIcon LoginImg = new ImageIcon("src/nagadaImg/LoginButton1.png");
        ImageIcon LoginImg2 = new ImageIcon("src/nagadaImg/LoginButton2.png");
        ImageIcon SignImg = new ImageIcon("src/nagadaImg/JoinButton1.png");
        ImageIcon SignImg2 = new ImageIcon("src/nagadaImg/JoinButton2.png");

        buttonLogin = new JButton(LoginImg);
        buttonLogin.setPressedIcon(LoginImg2); // 눌렀을 때의 이미지
        buttonLogin.setRolloverIcon(LoginImg2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonLogin.setBorderPainted(false); // 버튼 테두리 설정해제
        buttonLogin.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonLogin.setContentAreaFilled(false);

        buttonSignUp = new JButton(SignImg);
        buttonSignUp.setRolloverIcon(SignImg2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonSignUp.setBorderPainted(false);
        buttonSignUp.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonSignUp.setPressedIcon(SignImg2); // 눌렀을 때의 이미지
        buttonSignUp.setContentAreaFilled(false);


        buttonSignUp.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경


        // "나가다" 레이블
        labelNAGADA.setBounds(120, 130, 285, 60);

        // ID 레이블과 입력 필드

        labelID.setBounds(75, 262, 80, 40);
        textID.setBounds(188, 259, 280, 50);

        // PW 레이블과 입력 필드

        labelPW.setBounds(75, 370, 80, 40);
        textPW.setBounds(188, 367, 280, 50);

        // 로그인 버튼과 회원가입 버튼
        buttonLogin.setBounds(87, 460, 190, 68);
        buttonSignUp.setBounds(290, 460, 190, 68); // 185 65


        add(labelNAGADA);
        add(labelID);
        add(textID);
        add(labelPW);
        add(textPW);
        add(buttonLogin);
        add(buttonSignUp);


        setSize(550, 666);
        setResizable(false); // 프엔
        setLocationRelativeTo(null);
        setVisible(true);


        addListeners();
    }


    public void addListeners() {

        // 로그인 버튼 눌렀을 때
        ActionListener loginActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredID = textID.getText();
                char[] enteredPW = textPW.getPassword();
                setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

                if (!enteredID.isEmpty() && enteredPW.length > 0) {
                    String loginMessage = "LOGIN|" + enteredID + "|" + new String(enteredPW);
                    client.sendMessage(loginMessage);

                    try {
                        Thread.sleep(500);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                    boolean loginSuccess = waitForLoginResult();

                    if (loginSuccess) {
                        NagadaJDialog dialog = new NagadaJDialog("로그인 성공", "src/nagadaImg/DiaLogin.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); 
                        dialog.setVisible(true);
                        setVisible(false);
                        ClientGUI clientGUI = new ClientGUI(client);
                        clientGUI.setVisible(true);
                    } else {
                        NagadaJDialog dialog = new NagadaJDialog("로그인 실패", "src/nagadaImg/DiaError.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); 
                        dialog.setVisible(true);
                    }

                } else {
                    NagadaJDialog dialog = new NagadaJDialog("빈 칸 오류", "src/nagadaImg/DiaNoIDPW.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); 
                    dialog.setVisible(true);
                }
                setCursor(Cursor.getDefaultCursor());
            }
        };

        buttonLogin.addActionListener(loginActionListener);
        textPW.addActionListener(loginActionListener);
        textID.addActionListener(loginActionListener);


        // 회원가입 버튼 눌렀을 때
        buttonSignUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                JoinGUI joinGUI = new JoinGUI(client);
                joinGUI.setVisible(true);
            }
        });
    }


    private boolean waitForLoginResult() {
        long startTime = System.currentTimeMillis();
        long timeout = 2000;

        while (System.currentTimeMillis() - startTime < timeout) {
            if (client.getReceivedMessage() != null) {
                return client.getReceivedMessage().equals("LOGIN_SUCCESS");
            }
        }

        return false;
    }

}



