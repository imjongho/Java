package nagadaClient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import nagadaFront.*;

public class JoinGUI extends JFrame {

    private Client client;

    private JTextField textID;
    private JPasswordField textPW;
    private JTextField textName;
    private JTextField textGender;
    private JTextField textAge;
    private JTextField textPhone;
    private JTextField textAcc;
    private JTextField textBank;

    private JButton buttonReCheck;
    private JButton buttonJoin;
    private JButton buttonBack;
    private BackgroundPanel backgroundPanel;

    private String confirmID = "";

    public JoinGUI(Client client) {
        super("사용자 회원가입 화면");
        this.client = client;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); 

        backgroundPanel = new BackgroundPanel("src/nagadaImg/Join.png");
        backgroundPanel.setLayout(null);
        setContentPane(backgroundPanel);

        ImageIcon JoinButton1 = new ImageIcon("src/nagadaImg/JoinButton1.png");
        ImageIcon JoinButton2 = new ImageIcon("src/nagadaImg/JoinButton2.png");
        ImageIcon BackButton1 = new ImageIcon("src/nagadaImg/BackButton1.png");
        ImageIcon BackButton2 = new ImageIcon("src/nagadaImg/BackButton2.png");
        ImageIcon ReCheckButton1 = new ImageIcon("src/nagadaImg/ReCheckButton1.png");
        ImageIcon ReCheckButton2 = new ImageIcon("src/nagadaImg/ReCheckButton2.png");

        buttonJoin = new JButton(JoinButton1);
        buttonBack = new JButton(BackButton1);
        buttonReCheck = new JButton(ReCheckButton1);

        buttonReCheck.setPressedIcon(ReCheckButton2); // 눌렀을 때의 이미지
        buttonReCheck.setRolloverIcon(ReCheckButton2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonReCheck.setBorderPainted(false); // 버튼 테두리 설정해제
        buttonReCheck.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonReCheck.setContentAreaFilled(false);

        buttonJoin.setRolloverIcon(JoinButton2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonJoin.setPressedIcon(JoinButton2); // 눌렀을 때의 이미지
        buttonJoin.setBorderPainted(false);
        buttonJoin.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonJoin.setContentAreaFilled(false);

        buttonBack.setRolloverIcon(BackButton2); // 버튼에 마우스가 올라갈떄 이미지 변환
        buttonBack.setPressedIcon(BackButton2); // 눌렀을 때의 이미지
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusPainted(false); // 누르면 생기는 테두리 해제
        buttonBack.setContentAreaFilled(false);


        buttonReCheck.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경
        buttonJoin.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경
        buttonBack.setCursor(new Cursor(Cursor.HAND_CURSOR)); // 커서 변경

        JLabel labelSignup = new JLabel(" ", SwingConstants.CENTER); 
        JLabel labelID = new JLabel(" ");
        JLabel labelPW = new JLabel(" ");
        JLabel labelName = new JLabel(" ");
        JLabel labelGender = new JLabel(" ");
        JLabel labelAge = new JLabel(" ");
        JLabel labelPhone = new JLabel(" ");
        JLabel labelAcc = new JLabel(" ");
        Font font = new Font("맑은 고딕", 1, 25);
        textID = new JTextField();
        textID.setFont(font);
        textID.setBorder(null);
        textID.setOpaque(false);
        textPW = new JPasswordField();
        textPW.setFont(font);
        textPW.setBorder(null);
        textPW.setOpaque(false);
        textName = new JTextField();
        textName.setFont(font);
        textName.setBorder(null);
        textName.setOpaque(false);
        textGender = new JTextField();
        textGender.setFont(font);
        textGender.setOpaque(false);
        textGender.setBorder(null);
        textAge = new JTextField();
        textAge.setFont(font);
        textAge.setOpaque(false);
        textAge.setBorder(null);
        textPhone = new JTextField();
        textPhone.setFont(font);
        textPhone.setOpaque(false);
        textPhone.setBorder(null);
        textAcc = new JTextField();
        textAcc.setFont(font);
        textAcc.setOpaque(false);
        textAcc.setBorder(null);
        textBank = new JTextField();
        textBank.setFont(font);
        textBank.setOpaque(false);
        textBank.setBorder(null);

        int centerX = 250;
        labelSignup.setBounds(centerX + 10, 40, 200, 60);
        labelID.setBounds(centerX - 140, 135, 80, 40);
        textID.setBounds(centerX - 40, 135, 250, 40);
        labelPW.setBounds(centerX - 140, 210, 80, 40);
        textPW.setBounds(centerX - 40, 210, 250, 40);
        labelName.setBounds(centerX - 140, 290, 80, 40);
        textName.setBounds(centerX - 40, 290, 250, 40);
        labelGender.setBounds(centerX - 165, 380, 60, 40);
        textGender.setBounds(centerX - 75, 380, 80, 40);
        labelAge.setBounds(centerX + 55, 380, 80, 40);
        textAge.setBounds(centerX + 150, 380, 80, 40);
        labelPhone.setBounds(centerX - 160, 461, 80, 40);
        textPhone.setBounds(centerX - 40, 465, 250, 40);
        labelAcc.setBounds(centerX - 160, 545, 80, 40);
        textAcc.setBounds(centerX - 40, 550, 250, 40);
        textBank.setBounds(centerX + 305, 550, 89, 40);
        buttonJoin.setBounds(centerX - 65, 635, 200, 70);
        buttonReCheck.setBounds(centerX + 288, 130, 129, 66);
        buttonBack.setBounds(centerX + 165, 635, 200, 70);

        add(labelSignup);
        add(labelID);
        add(labelPW);
        add(labelName);
        add(labelGender);
        add(labelAge);
        add(labelPhone);
        add(labelAcc);
        add(labelSignup);
        add(textID);
        add(textPW);
        add(textName);
        add(textGender);
        add(textAge);
        add(textPhone);
        add(textAcc);
        add(textBank);
        add(buttonReCheck);
        add(buttonJoin);
        add(buttonBack);

       
        setSize(750, 750);
        setResizable(false); // 프엔
        setLocationRelativeTo(null);
        setVisible(true);

        
        addListeners();
    }


    private void addListeners() {

        buttonReCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = textID.getText();

                if (!id.isEmpty()) {
                    String idCheckMessage = "ID_CHECK|" + id;
                    client.sendMessage(idCheckMessage);

                    try {
                        Thread.sleep(500);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                    boolean isIDAvailable = waitForIDCheckResult();

                    if (isIDAvailable) {
                        NagadaJDialog dialog = new NagadaJDialog("ID 사용 가능", "src/nagadaImg/DiaYesID.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                        dialog.setVisible(true);
                        confirmID = id;
                    } else {
                        NagadaJDialog dialog = new NagadaJDialog("ID 사용 불가", "src/nagadaImg/DiaNoID.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                        dialog.setVisible(true);
                    }
                } else {
                    NagadaJDialog dialog = new NagadaJDialog("ID 칸 공백", "src/nagadaImg/DiaNoID.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                    dialog.setVisible(true);
                }
            }
        });


        buttonJoin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = textID.getText();
                char[] pw = textPW.getPassword();
                String name = textName.getText();
                String gender = textGender.getText();
                String age = textAge.getText();
                String phone = textPhone.getText();
                String acc = textAcc.getText();
                String bank = textBank.getText();

                if (!id.isEmpty() && pw.length > 0 && !name.isEmpty() && !gender.isEmpty() && !age.isEmpty() && !phone.isEmpty() && !acc.isEmpty() && !bank.isEmpty()) {

                    if (confirmID.equals(textID.getText())) {
                        String signupMessage = "SIGNUP|" + id + "|" + new String(pw) + "|" + name + "|" + gender + "|" +
                                age + "|" + phone + "|" + acc + "|" + bank;
                        client.sendMessage(signupMessage);

                        try {
                            Thread.sleep(500);
                        } catch (Exception e1) {
                            e1.printStackTrace();
                        }

                        boolean isSignUpFinish = waitForSignUpResult();

                        if (isSignUpFinish) {
                            NagadaJDialog dialog = new NagadaJDialog("회원가입 완료", "src/nagadaImg/DiaJoin.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                            dialog.setVisible(true);
                            JoinGUI.this.dispose();
                            new LoginGUI(client);
                        } else {
                            NagadaJDialog dialog = new NagadaJDialog("회원가입 실패", "src/nagadaImg/DiaError.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                            dialog.setVisible(true);
                        }
                    } else {
                        NagadaJDialog dialog = new NagadaJDialog("중복확인", "src/nagadaImg/DiaNoReCheck.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                        dialog.setVisible(true);
                    }

                } else {
                    NagadaJDialog dialog = new NagadaJDialog("빈 칸 오류", "src/nagadaImg/DiaBlank.png", "src/nagadaImg/CheckButton1.png", "src/nagadaImg/CheckButton2.png"); // 이미지 경로를 적절히 수정해주세요.
                    dialog.setVisible(true);
                }
            }
        });

        buttonBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JoinGUI.this.dispose();
                new LoginGUI(client);
            }
        });
    }


    private boolean waitForIDCheckResult() {
        long startTime = System.currentTimeMillis();
        long timeout = 2000; 

        // 3초동안 while문 돌며 서버로부터 답장 받음
        while (System.currentTimeMillis() - startTime < timeout) {
            if (client.getReceivedMessage() != null) {
                return client.getReceivedMessage().equals("ID_AVAILABLE");
            }
        }

        return false;
    }


    private boolean waitForSignUpResult() {
        long startTime = System.currentTimeMillis();
        long timeout = 2000; 

        while (System.currentTimeMillis() - startTime < timeout) {
            if (client.getReceivedMessage() != null) {
                return client.getReceivedMessage().equals("SIGNUP_SUCCESS");
            }
        }

        return false;
    }


}






