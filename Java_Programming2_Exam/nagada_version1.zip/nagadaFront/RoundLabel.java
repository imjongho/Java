package nagadaFront;

import java.awt.*;
import javax.swing.*;

public class RoundLabel extends JPanel {
    private String text;
    private Color borderColor;

    public RoundLabel(String text, Color borderColor) {
        this.text = text;
        this.borderColor = borderColor;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw background
        graphics.setColor(getBackground());
        graphics.fillRoundRect(0, 0, width, height, 20, 20);

        // Draw border
        graphics.setColor(borderColor);
        graphics.drawRoundRect(0, 0, width - 1, height - 1, 20, 20);

        // Draw text
        graphics.setColor(getForeground());
        graphics.setFont(getFont());
        FontMetrics fontMetrics = graphics.getFontMetrics();
        int stringWidth = fontMetrics.stringWidth(text);
        int stringHeight = fontMetrics.getAscent();
        graphics.drawString(text, (width - stringWidth) / 2, height / 2 + 5 + stringHeight / 4);
    }
}